# Bazar — Marketplace didáctico

Pieza educativa de e-commerce **100 % cliente**: HTML + CSS + JavaScript vanilla,
sin frameworks, sin internet, sin APIs externas. Se sirve desde Apache2 sobre
una VM, simulando un marketplace completo (catálogo, carrito, checkout con
pasarela de pago animada, historial de pedidos).

---

## 🧩 Lo que demuestra

- **Arquitectura limpia en 4 capas**: `domain/`, `application/`, `infrastructure/`, `presentation/`.
- **Inversión de dependencias** explícita: la composición vive en `js/main.js`.
- **Ningún framework**: solo módulos ES6 nativos (Apache los sirve sin configuración extra).
- **Persistencia local** vía `localStorage` (carrito + pedidos sobreviven al refresh).
- **Pasarela de pago simulada** en 4 etapas (validación → emisor → autorización → aprobación).
- **Router SPA por hash** (no requiere `mod_rewrite`).

---

## 📁 Estructura

```
bazar/
├── index.html
├── css/                          # 11 archivos por responsabilidad (reset, tokens, base, layout, …)
├── fotos/                        # 6 PNGs imagen1..imagen6 (los provee el usuario)
└── js/
    ├── main.js                   # Composition root
    ├── domain/                   # Entidades puras: Product, Cart, CartItem, Order
    ├── application/              # Casos de uso: ProductCatalog, CartService, OrderService, FakePaymentGateway
    ├── infrastructure/           # Repos + adapters: StorageAdapter, ProductRepository, CartRepository, OrderRepository, ProductSeed
    └── presentation/             # Router, formato, ImageResolver, Toast, vistas y componentes
```

Las dependencias **siempre** apuntan hacia el dominio: `presentation → application → domain`,
y `infrastructure → domain`. El dominio no importa nada de las otras capas.

---

## 🖼 Imágenes de producto

1. Conseguí 6 PNGs con **el mismo width × height** entre sí (recomendado 800×1000 px).
2. Renombralos `imagen1.png` … `imagen6.png`.
3. Dejalos en `bazar/fotos/`.

El módulo `presentation/ImageResolver.js` los asigna a los productos de forma
pseudo-aleatoria pero estable por sesión.

---

## 🚀 Deploy en la VM (Apache2)

### 1. Subir el zip por SCP

Desde tu máquina:

```bash
scp bazar.zip usuario@IP-DE-LA-VM:/tmp/
```

### 2. Conectarte por SSH

```bash
ssh usuario@IP-DE-LA-VM
```

### 3. Descomprimir en el docroot

**Opción A — accesible en `http://IP/bazar/`** (recomendada, no pisa el sitio default):

```bash
sudo unzip /tmp/bazar.zip -d /var/www/html/
sudo chown -R www-data:www-data /var/www/html/bazar
sudo chmod -R 755 /var/www/html/bazar
```

**Opción B — accesible en la raíz `http://IP/`** (reemplaza el `index.html` default):

```bash
sudo unzip -j /tmp/bazar.zip "bazar/*" -d /var/www/html/
# Las subcarpetas hay que copiarlas aparte porque -j aplana
sudo unzip -o /tmp/bazar.zip "bazar/css/*" "bazar/js/*" "bazar/fotos/*" -d /tmp/bazar-extracted
sudo cp -r /tmp/bazar-extracted/bazar/* /var/www/html/
sudo chown -R www-data:www-data /var/www/html
```

> 💡 La Opción A es más limpia. Si querés la B, lo más simple es:
> ```bash
> sudo unzip /tmp/bazar.zip -d /tmp/
> sudo rm /var/www/html/index.html
> sudo cp -r /tmp/bazar/* /var/www/html/
> sudo chown -R www-data:www-data /var/www/html
> ```

### 4. Subir las 6 imágenes

```bash
# Desde tu máquina
scp imagen{1,2,3,4,5,6}.png usuario@IP-DE-LA-VM:/tmp/
# En la VM
sudo mv /tmp/imagen*.png /var/www/html/bazar/fotos/
sudo chown www-data:www-data /var/www/html/bazar/fotos/*.png
```

### 5. Probar

Apache2 en Ubuntu sirve `.js` con MIME `application/javascript` por defecto, lo
cual es suficiente para módulos ES6. **No requiere configuración adicional.**

Abrí el navegador:

```
http://IP-DE-LA-VM/bazar/
```

(o `http://IP-DE-LA-VM/` si elegiste la opción B).

---

## 🧪 Recorrido sugerido para la demo

1. Catálogo — filtrá por categoría usando los chips.
2. Click en una card → detalle del producto, agregá 2 unidades.
3. Volvé al catálogo, agregá otro producto distinto.
4. Ícono de carrito → ajustá cantidades, mirá el progreso de envío gratis.
5. Ir a Checkout → completá los datos. Probá:
   - **Tarjeta**: cualquier número de 16 dígitos; el formulario detecta la marca por prefijo (4 = Visa, 5 = Mastercard).
   - **PSE** o **Contraentrega** funcionan también.
6. Mirá la animación de los 4 pasos de la pasarela.
7. Al confirmar, te redirige a `/success/BZR-XXXXXX-YY`.
8. Abrí *Mis pedidos* → expandí el detalle del último.

---

## 🧹 Limpieza (sin reinstalar)

Para limpiar los datos del navegador (carrito + pedidos) abrí DevTools →
Application → Local Storage y borrá las claves `bazar.*`. O en consola:

```js
Object.keys(localStorage).filter(k => k.startsWith('bazar.')).forEach(k => localStorage.removeItem(k));
location.reload();
```

---

## 📝 Notas técnicas

- **Sin internet**: no se carga ningún recurso externo. Las fuentes son
  exclusivamente del sistema operativo (Georgia / system-ui / SF Mono).
- **Sin `mod_rewrite`**: el router usa `location.hash`, así no tenés que tocar
  `.htaccess` ni habilitar módulos extra.
- **Compatibilidad**: navegadores con soporte de módulos ES6 (Chrome 61+,
  Firefox 60+, Safari 11+, Edge 79+).
- **Reset rápido**: para llevarlo a otra máquina, solo copiá la carpeta `bazar/`
  entera. No hay build step, no hay `npm install`.

---

Hecho con cuidado — Bazar.
