/**
 * Capa: APLICACIÓN
 * OrderService — Casos de uso para pedidos:
 *   - placeOrder(cart, customer, payment) — crea, persiste y devuelve un Order
 *   - getHistory()
 *   - getById(id)
 */
import { Order } from '../domain/Order.js';

export class OrderService {
  constructor(orderRepository) {
    this.repo = orderRepository;
  }

  placeOrder(cart, customer, payment) {
    if (cart.isEmpty) throw new Error('No se puede generar pedido con carrito vacío');

    const order = new Order({
      id: Order.generateId(),
      createdAt: new Date().toISOString(),
      items: cart.items.map(i => i.toJSON()),
      customer,
      payment,
      subtotal: cart.subtotal,
      shippingCost: cart.shippingCost,
      taxes: cart.taxes,
      total: cart.total,
      status: 'paid',
    });
    this.repo.saveOne(order);
    return order;
  }

  getHistory() {
    return this.repo.loadAll();
  }

  getById(id) {
    return this.repo.findById(id);
  }
}
