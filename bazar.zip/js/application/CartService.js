/**
 * Capa: APLICACIÓN
 * CartService — Casos de uso del carrito.
 *   - addProduct(product, qty)
 *   - changeQuantity(productId, qty)
 *   - removeProduct(productId)
 *   - clear()
 *   - subscribe(listener)  — patrón observer para refrescar UI
 *
 * Mantiene una copia viva del carrito y emite eventos cuando cambia.
 */
import { Cart } from '../domain/Cart.js';
import { CartItem } from '../domain/CartItem.js';

export class CartService {
  constructor(cartRepository) {
    this.repo = cartRepository;
    this._cart = this.repo.load();
    this._listeners = new Set();
  }

  getCart() {
    return this._cart;
  }

  addProduct(product, quantity = 1) {
    const item = new CartItem({
      productId: product.id,
      name: product.name,
      vendor: product.vendor,
      unitPrice: product.price,
      quantity,
    });
    this._update(this._cart.addItem(item));
  }

  changeQuantity(productId, quantity) {
    this._update(this._cart.setQuantity(productId, quantity));
  }

  removeProduct(productId) {
    this._update(this._cart.removeItem(productId));
  }

  clear() {
    this._update(Cart.empty());
  }

  subscribe(fn) {
    this._listeners.add(fn);
    return () => this._listeners.delete(fn);
  }

  _update(cart) {
    this._cart = cart;
    this.repo.save(cart);
    this._listeners.forEach(fn => fn(cart));
  }
}
