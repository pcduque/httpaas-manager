/**
 * Capa: APLICACIÓN
 * ProductCatalog — orquesta búsquedas y filtros sobre el repositorio.
 * Aísla las vistas de la implementación de almacenamiento.
 */
export class ProductCatalog {
  constructor(productRepository) {
    this.repo = productRepository;
  }

  list({ category = 'all', query = '' } = {}) {
    let result = this.repo.findAll();

    if (category && category !== 'all') {
      result = result.filter(p => p.category === category);
    }
    if (query && query.trim()) {
      const q = query.trim().toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.vendor.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
      );
    }
    return result;
  }

  getById(id) {
    return this.repo.findById(id);
  }

  getCategories() {
    return this.repo.getCategories();
  }
}
