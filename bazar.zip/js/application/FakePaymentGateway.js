/**
 * Capa: APLICACIÓN
 * FakePaymentGateway — Pasarela simulada que SIEMPRE aprueba.
 *
 * Puramente educativa. Simula varias etapas con latencia y emite eventos
 * de progreso para que la UI muestre los pasos:
 *   1) Validación de datos
 *   2) Comunicación con emisor
 *   3) Autenticación 3DS
 *   4) Aprobación
 *
 * Devuelve una promesa que se resuelve con el resultado.
 */
const STEPS = [
  { key: 'validate',  label: 'Validando datos de tarjeta',     delay: 700 },
  { key: 'issuer',    label: 'Comunicando con el emisor',      delay: 900 },
  { key: 'auth',      label: 'Autenticación 3D Secure',        delay: 800 },
  { key: 'approve',   label: 'Pago aprobado',                  delay: 600 },
];

export class FakePaymentGateway {
  /**
   * @param {Object} payload — datos del cliente, monto, etc. (no se procesan, sólo se loggean)
   * @param {Function} onStep — callback(stepKey) cada vez que avanza
   * @returns {Promise<{ok: true, transactionId, authCode, brand, last4}>}
   */
  charge(payload, onStep = () => {}) {
    return new Promise((resolve) => {
      let i = 0;

      const tick = () => {
        if (i >= STEPS.length) {
          resolve({
            ok: true,
            transactionId: this._txId(),
            authCode: this._authCode(),
            brand: this._guessBrand(payload?.cardNumber || ''),
            last4: (payload?.cardNumber || '').replace(/\s+/g, '').slice(-4) || '0000',
          });
          return;
        }
        const step = STEPS[i++];
        setTimeout(() => {
          onStep(step.key, step.label);
          tick();
        }, step.delay);
      };
      tick();
    });
  }

  static getSteps() {
    return STEPS.map(s => ({ key: s.key, label: s.label }));
  }

  _txId() {
    return 'TX' + Math.random().toString(36).slice(2, 12).toUpperCase();
  }

  _authCode() {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  _guessBrand(num) {
    const cleaned = num.replace(/\s+/g, '');
    if (cleaned.startsWith('4')) return 'Visa';
    if (/^5[1-5]/.test(cleaned)) return 'Mastercard';
    if (/^3[47]/.test(cleaned)) return 'American Express';
    if (cleaned.startsWith('6')) return 'Discover';
    return 'Tarjeta';
  }
}
