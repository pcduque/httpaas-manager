/**
 * Capa: INFRAESTRUCTURA
 * Adaptador delgado sobre localStorage. Centraliza serialización y manejo de errores.
 * Si el navegador no permite storage (modo privado, cuotas), degrada a un Map en memoria.
 */
class MemoryFallback {
  constructor() { this.map = new Map(); }
  getItem(k) { return this.map.has(k) ? this.map.get(k) : null; }
  setItem(k, v) { this.map.set(k, v); }
  removeItem(k) { this.map.delete(k); }
}

function detectStorage() {
  try {
    const t = '__bazar_test__';
    localStorage.setItem(t, '1');
    localStorage.removeItem(t);
    return localStorage;
  } catch {
    console.warn('[Bazar] localStorage no disponible — usando memoria.');
    return new MemoryFallback();
  }
}

const storage = detectStorage();

export const StorageAdapter = {
  read(key, fallback = null) {
    try {
      const raw = storage.getItem(key);
      if (raw === null || raw === undefined) return fallback;
      return JSON.parse(raw);
    } catch (err) {
      console.warn(`[Bazar] error leyendo "${key}":`, err);
      return fallback;
    }
  },

  write(key, value) {
    try {
      storage.setItem(key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.warn(`[Bazar] error escribiendo "${key}":`, err);
      return false;
    }
  },

  remove(key) {
    try {
      storage.removeItem(key);
      return true;
    } catch { return false; }
  },
};
