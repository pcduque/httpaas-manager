/**
 * Capa: INFRAESTRUCTURA
 * ProductRepository — fuente única para acceder a productos del catálogo.
 * Recibe la semilla y construye entidades. En memoria, no escribe nada.
 */
import { Product } from '../domain/Product.js';
import { PRODUCT_SEED, CATEGORIES } from './ProductSeed.js';

export class ProductRepository {
  constructor(seed = PRODUCT_SEED) {
    this._products = seed.map(p => new Product(p));
  }

  findAll() {
    return [...this._products];
  }

  findById(id) {
    return this._products.find(p => p.id === id) || null;
  }

  findByCategory(category) {
    if (!category || category === 'all') return this.findAll();
    return this._products.filter(p => p.category === category);
  }

  search(text) {
    const t = text.trim().toLowerCase();
    if (!t) return this.findAll();
    return this._products.filter(p =>
      p.name.toLowerCase().includes(t) ||
      p.vendor.toLowerCase().includes(t) ||
      p.category.toLowerCase().includes(t)
    );
  }

  getCategories() {
    return [...CATEGORIES];
  }
}
