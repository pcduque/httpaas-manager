/**
 * Capa: INFRAESTRUCTURA
 * OrderRepository — persiste el historial de pedidos en localStorage.
 */
import { Order } from '../domain/Order.js';
import { StorageAdapter } from './StorageAdapter.js';

const KEY = 'bazar.orders.v1';

export class OrderRepository {
  loadAll() {
    const list = StorageAdapter.read(KEY, []);
    if (!Array.isArray(list)) return [];
    return list
      .map(raw => { try { return new Order(raw); } catch { return null; } })
      .filter(Boolean)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  saveOne(order) {
    const all = this.loadAll();
    all.unshift(order);
    return StorageAdapter.write(KEY, all.map(o => o.toJSON()));
  }

  findById(id) {
    return this.loadAll().find(o => o.id === id) || null;
  }

  clearAll() {
    return StorageAdapter.remove(KEY);
  }
}
