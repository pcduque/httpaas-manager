/**
 * Capa: INFRAESTRUCTURA
 * CartRepository — persiste el carrito vivo del usuario en localStorage.
 */
import { Cart } from '../domain/Cart.js';
import { CartItem } from '../domain/CartItem.js';
import { StorageAdapter } from './StorageAdapter.js';

const KEY = 'bazar.cart.v1';

export class CartRepository {
  load() {
    const data = StorageAdapter.read(KEY);
    if (!data || !Array.isArray(data.items)) return Cart.empty();
    try {
      const items = data.items.map(i => new CartItem(i));
      return new Cart(items);
    } catch {
      return Cart.empty();
    }
  }

  save(cart) {
    return StorageAdapter.write(KEY, cart.toJSON());
  }

  clear() {
    return StorageAdapter.remove(KEY);
  }
}
