/**
 * Capa: PRESENTACIÓN — componente
 * ProductCard — Renderiza una card del catálogo.
 */
import { html } from '../format.js';
import { formatPrice } from '../format.js';
import { ImageResolver } from '../ImageResolver.js';

const ICON_PLUS = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>`;
const ICON_STAR = `<svg viewBox="0 0 24 24"><path d="M12 2l2.6 6.5 7 .6-5.3 4.6 1.6 6.8L12 16.8 6.1 20.5l1.6-6.8L2.4 9.1l7-.6z"/></svg>`;

/**
 * @param {Product} product
 * @returns {string} HTML
 */
export function renderProductCard(product) {
  const img = ImageResolver.pathFor(product.id);
  const fallbackChar = product.name.charAt(0).toUpperCase();
  const tagHtml = product.tag
    ? `<span class="badge-tag is-${product.tag.kind} product-tag">${product.tag.label}</span>`
    : '';

  return html`
    <article class="product-card" data-product-id="${product.id}" tabindex="0" aria-label="${product.name}">
      <div class="product-image-wrap">
        ${{__html: tagHtml}}
        <button class="product-fav" type="button" aria-label="Guardar como favorito" data-action="favorite">
          <svg viewBox="0 0 24 24"><path d="M12 21s-7-4.3-9.5-9.1C.7 8.7 2.7 5 6.2 5 8.4 5 9.9 6.4 12 8.5 14.1 6.4 15.6 5 17.8 5c3.5 0 5.5 3.7 3.7 6.9C19 16.7 12 21 12 21z"/></svg>
        </button>
        <img src="${img}" alt="${product.name}" loading="lazy"
             onerror="this.style.display='none'; this.parentElement.querySelector('.img-fallback').style.display='block';" />
        <span class="img-fallback" style="display:none">${fallbackChar}</span>
      </div>
      <div class="product-body">
        <div class="product-meta">
          <span class="vendor">${product.vendor}</span>
          <span class="rating">${{__html: ICON_STAR}} ${product.rating.toFixed(1)}</span>
        </div>
        <h3 class="product-title">${product.name}</h3>
        <div class="product-footer">
          <div class="product-price">
            <span class="price-amount">${formatPrice(product.price, product.currency)}</span>
            ${product.hasDiscount
              ? html`<span class="price-old">${formatPrice(product.oldPrice, product.currency)}</span>`
              : ''}
          </div>
          <button class="add-mini" type="button" aria-label="Añadir al carrito" data-action="add">
            ${{__html: ICON_PLUS}}
          </button>
        </div>
      </div>
    </article>
  `;
}
