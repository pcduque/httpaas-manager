/**
 * Capa: PRESENTACIÓN — componente
 * Header — recibe el cartService para mostrar el contador del carrito en vivo.
 */
import { Router } from '../Router.js';

const ICONS = {
  bag: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8h14l-1 12H6L5 8z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/></svg>`,
  receipt: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3v18l3-2 3 2 3-2 3 2V3z"/><path d="M9 8h6M9 12h6M9 16h4"/></svg>`,
};

export function renderHeader(cartService) {
  const headerEl = document.getElementById('app-header');
  headerEl.innerHTML = `
    <div class="header-inner">
      <a class="brand" href="#/" aria-label="Bazar — inicio">
        <span class="brand-mark">B</span>
        <span class="brand-name">BAZAR</span>
        <span class="brand-suffix">· est. 2024</span>
      </a>
      <nav class="nav-primary" aria-label="Navegación principal">
        <a class="nav-link" data-route="/" href="#/">Tienda</a>
        <a class="nav-link" data-route="/orders" href="#/orders">Mis pedidos</a>
        <a class="nav-link" data-route="/cart" href="#/cart">Carrito</a>
      </nav>
      <div class="header-actions">
        <a class="icon-btn" href="#/orders" aria-label="Historial de pedidos">
          ${ICONS.receipt}
        </a>
        <a class="icon-btn" href="#/cart" aria-label="Ver carrito">
          ${ICONS.bag}
          <span id="cart-badge" class="badge">0</span>
        </a>
      </div>
    </div>
  `;

  // Sincroniza el badge del carrito con cambios
  const updateBadge = (cart) => {
    const badge = document.getElementById('cart-badge');
    if (!badge) return;
    badge.textContent = cart.itemCount;
    badge.classList.toggle('is-visible', cart.itemCount > 0);
  };
  updateBadge(cartService.getCart());
  cartService.subscribe(updateBadge);

  // Marca la nav activa según la ruta actual
  const setActive = (hash) => {
    const path = hash.split('?')[0];
    headerEl.querySelectorAll('.nav-link').forEach(a => {
      const route = a.dataset.route;
      const isActive =
        (route === '/' && (path === '/' || path === ''))
        || (route !== '/' && path.startsWith(route));
      a.classList.toggle('is-active', isActive);
    });
  };
  setActive(location.hash.slice(1) || '/');
  window.addEventListener('hashchange', () => setActive(location.hash.slice(1) || '/'));
}
