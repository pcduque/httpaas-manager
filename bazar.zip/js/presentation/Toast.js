/**
 * Capa: PRESENTACIÓN — Toast (notificaciones efímeras)
 */
const ICONS = {
  success: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13l4 4L19 7"/></svg>`,
  info: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M12 8v4M12 16h.01"/></svg>`,
};

class ToastImpl {
  constructor() {
    this._stack = null;
  }

  _ensure() {
    if (!this._stack) this._stack = document.getElementById('toast-stack');
  }

  show(message, { kind = 'info', duration = 2600 } = {}) {
    this._ensure();
    if (!this._stack) return;

    const el = document.createElement('div');
    el.className = `toast toast-${kind}`;
    el.innerHTML = `
      <div class="toast-icon" style="color: var(--paper)">${ICONS[kind] || ICONS.info}</div>
      <span class="toast-msg"></span>
    `;
    el.querySelector('.toast-msg').textContent = message;
    this._stack.appendChild(el);

    setTimeout(() => {
      el.classList.add('is-leaving');
      setTimeout(() => el.remove(), 260);
    }, duration);
  }

  success(msg) { this.show(msg, { kind: 'success' }); }
  info(msg) { this.show(msg, { kind: 'info' }); }
}

export const Toast = new ToastImpl();
