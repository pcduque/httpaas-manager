/**
 * Capa: PRESENTACIÓN
 * ImageResolver — asigna a cada producto una imagen del pool /fotos/imagenN.png
 *
 * El usuario coloca imagen1.png … imagen6.png en /fotos.
 * Para cada producto elegimos un índice aleatorio que se mantiene durante la sesión
 * (estable entre rerenders) — así la card y el detalle muestran la misma foto.
 *
 * La asignación se persiste en sessionStorage para sobrevivir a navegación.
 * Si el usuario cierra el tab y vuelve, se reasigna (sigue siendo "random").
 */
const POOL_SIZE = 6;
const SESSION_KEY = 'bazar.imgmap.session';

class ImageResolverImpl {
  constructor() {
    this._map = this._loadMap();
    this._missing = new Set();
  }

  _loadMap() {
    try {
      const raw = sessionStorage.getItem(SESSION_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch { return {}; }
  }

  _persist() {
    try { sessionStorage.setItem(SESSION_KEY, JSON.stringify(this._map)); }
    catch {/* noop */}
  }

  /** Devuelve un índice 1..6 estable para cada productId. */
  indexFor(productId) {
    if (this._map[productId]) return this._map[productId];
    const idx = 1 + Math.floor(Math.random() * POOL_SIZE);
    this._map[productId] = idx;
    this._persist();
    return idx;
  }

  /** Ruta del archivo asignado al producto. */
  pathFor(productId) {
    return `fotos/imagen${this.indexFor(productId)}.png`;
  }

  /** Lista de paths para galería de detalle (la principal + 3 alternativas distintas). */
  galleryFor(productId) {
    const main = this.indexFor(productId);
    const others = [];
    for (let i = 1; i <= POOL_SIZE; i++) if (i !== main) others.push(i);
    // mezcla determinística simple
    const seed = this._hash(productId);
    others.sort((a, b) => ((seed + a) % 7) - ((seed + b) % 7));
    const indices = [main, ...others.slice(0, 3)];
    return indices.map(i => `fotos/imagen${i}.png`);
  }

  _hash(s) {
    let h = 0;
    for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
    return Math.abs(h);
  }

  /** Marca una ruta como inexistente (cuando el <img> dispara onerror). */
  markMissing(path) { this._missing.add(path); }
  isMissing(path) { return this._missing.has(path); }
}

export const ImageResolver = new ImageResolverImpl();
