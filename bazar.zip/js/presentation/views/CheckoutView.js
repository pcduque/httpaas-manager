/**
 * Capa: PRESENTACIÓN — vista
 * CheckoutView — formulario de cliente + pasarela simulada.
 *
 * Etapas:
 *   1) Formulario (datos cliente + tarjeta)
 *   2) Procesando (animación + pasos del gateway)
 *   3) Éxito (delegado a SuccessView vía router)
 */
import { formatPrice } from '../format.js';
import { ImageResolver } from '../ImageResolver.js';
import { FakePaymentGateway } from '../../application/FakePaymentGateway.js';
import { Toast } from '../Toast.js';

export function CheckoutView({ cartService, orderService }) {
  const root = document.createElement('div');
  root.className = 'container';
  const cart = cartService.getCart();

  // Si el carrito está vacío, redirigimos
  if (cart.isEmpty) {
    root.innerHTML = `
      <div class="empty-state">
        <h3>Tu carrito está vacío</h3>
        <p>Añadí productos antes de procesar un pago.</p>
        <a class="btn btn-primary" href="#/">Ir al catálogo</a>
      </div>`;
    return root;
  }

  // Estado local
  const state = {
    method: 'card',
    cardNumber: '',
    cardName: '',
    cardExp: '',
    cardCvv: '',
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    notes: '',
    errors: {},
  };

  const renderForm = () => {
    const sm = cart.summary;
    root.innerHTML = `
      <header style="margin-bottom: var(--sp-6);">
        <p class="eyebrow">PASO 02 DE 03</p>
        <h1 style="font-size: var(--fs-2xl); margin-top: var(--sp-2);">Pago seguro</h1>
        <p class="subtitle">Pasarela 100% simulada — ningún dato sale del navegador.</p>
      </header>

      <div class="checkout-stepper" aria-label="Progreso del pedido">
        <span class="step"><span class="step-num">1</span> Carrito</span>
        <span class="step-divider">—</span>
        <span class="step is-active"><span class="step-num">2</span> Pago</span>
        <span class="step-divider">—</span>
        <span class="step"><span class="step-num">3</span> Confirmación</span>
      </div>

      <div class="checkout-page">
        <form id="checkout-form" novalidate>
          <section class="checkout-section">
            <h3>Datos de contacto</h3>
            <p class="section-sub">¿Cómo te encontramos?</p>
            <div class="form-grid">
              <label class="field">
                <span class="field-label">Nombre completo</span>
                <input class="input" name="fullName" required autocomplete="name" />
              </label>
              <label class="field">
                <span class="field-label">Correo</span>
                <input class="input" name="email" type="email" required autocomplete="email" />
              </label>
              <label class="field">
                <span class="field-label">Teléfono</span>
                <input class="input" name="phone" required autocomplete="tel" />
              </label>
              <label class="field">
                <span class="field-label">Ciudad</span>
                <input class="input" name="city" required />
              </label>
              <label class="field full">
                <span class="field-label">Dirección de envío</span>
                <input class="input" name="address" required autocomplete="street-address" />
              </label>
              <label class="field full">
                <span class="field-label">Notas (opcional)</span>
                <textarea class="textarea" name="notes" rows="2" placeholder="Indicaciones, horario..."></textarea>
              </label>
            </div>
          </section>

          <section class="checkout-section">
            <h3>Método de pago</h3>
            <p class="section-sub">Elegí cómo querés pagar (todos son simulados).</p>
            <div class="payment-methods" role="radiogroup">
              ${renderMethod('card', 'Tarjeta crédito/débito', state.method === 'card')}
              ${renderMethod('pse', 'PSE — Cuenta bancaria', state.method === 'pse')}
              ${renderMethod('cash', 'Efectivo contraentrega', state.method === 'cash')}
            </div>

            <div id="card-block">
              ${renderCardBlock(state)}
            </div>
          </section>

          <button type="submit" class="btn btn-accent btn-lg btn-block">
            Pagar ${formatPrice(sm.total)}
          </button>
        </form>

        <aside class="summary-card">
          <h3>Tu pedido</h3>
          <div class="cart-list" style="gap: var(--sp-2); max-height: 280px; overflow-y: auto;">
            ${cart.items.map(item => `
              <div style="display:flex; gap: var(--sp-3); align-items:center; padding-bottom: var(--sp-2); border-bottom: 1px dashed var(--line-soft);">
                <div style="width:48px;height:48px;border-radius:var(--r-sm);background:var(--paper-soft);overflow:hidden;flex-shrink:0;">
                  <img src="${ImageResolver.pathFor(item.productId)}" alt="" style="width:100%;height:100%;object-fit:cover;" onerror="this.style.opacity=.1"/>
                </div>
                <div style="flex:1;min-width:0;">
                  <div style="font-size:var(--fs-sm); font-weight:600; line-height:1.2;">${escape(item.name)}</div>
                  <div style="font-family:var(--font-mono); font-size:var(--fs-xs); color:var(--muted);">×${item.quantity}</div>
                </div>
                <div class="price" style="font-size:var(--fs-sm); font-weight:700;">
                  ${formatPrice(item.subtotal)}
                </div>
              </div>
            `).join('')}
          </div>
          <div class="summary-row"><span>Subtotal</span><span class="price">${formatPrice(sm.subtotal)}</span></div>
          <div class="summary-row">
            <span>Envío</span>
            <span class="price">${sm.hasFreeShipping ? '<span class="badge-tag is-leaf">Gratis</span>' : formatPrice(sm.shippingCost)}</span>
          </div>
          <div class="summary-row is-total"><span>Total</span><span class="price">${formatPrice(sm.total)}</span></div>
          <p class="summary-help">Cifrado en este navegador · Sin servicios externos</p>
        </aside>
      </div>
    `;

    bindForm();
  };

  const bindForm = () => {
    // Selector de método de pago
    root.querySelectorAll('.payment-method').forEach(el => {
      el.addEventListener('click', () => {
        state.method = el.dataset.method;
        root.querySelectorAll('.payment-method').forEach(m => m.classList.remove('is-active'));
        el.classList.add('is-active');
        const radio = el.querySelector('input[type="radio"]');
        if (radio) radio.checked = true;

        // mostrar/ocultar bloque de tarjeta
        const cardBlock = root.querySelector('#card-block');
        if (cardBlock) {
          cardBlock.style.display = state.method === 'card' ? '' : 'none';
        }
      });
    });

    // Inputs de tarjeta - máscaras visuales
    bindCardMasking();

    // Submit
    const form = root.querySelector('#checkout-form');
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      // validar
      const data = readForm(form);
      Object.assign(state, data);

      const errors = validate(state);
      if (Object.keys(errors).length) {
        showErrors(form, errors);
        Toast.info('Revisá los campos marcados.');
        return;
      }
      processPayment();
    });
  };

  const bindCardMasking = () => {
    const numEl = root.querySelector('input[name="cardNumber"]');
    const expEl = root.querySelector('input[name="cardExp"]');
    const cvvEl = root.querySelector('input[name="cardCvv"]');
    const previewNum = root.querySelector('#cc-prev-num');
    const previewName = root.querySelector('#cc-prev-name');
    const previewExp = root.querySelector('#cc-prev-exp');
    const nameEl = root.querySelector('input[name="cardName"]');

    numEl?.addEventListener('input', () => {
      const digits = numEl.value.replace(/\D/g, '').slice(0, 16);
      numEl.value = digits.replace(/(\d{4})(?=\d)/g, '$1 ').trim();
      if (previewNum) {
        const padded = digits.padEnd(16, '•');
        previewNum.textContent = padded.replace(/(.{4})/g, '$1 ').trim();
      }
    });

    expEl?.addEventListener('input', () => {
      const digits = expEl.value.replace(/\D/g, '').slice(0, 4);
      expEl.value = digits.length > 2 ? `${digits.slice(0,2)}/${digits.slice(2)}` : digits;
      if (previewExp) previewExp.textContent = expEl.value || 'MM/AA';
    });

    cvvEl?.addEventListener('input', () => {
      cvvEl.value = cvvEl.value.replace(/\D/g, '').slice(0, 4);
    });

    nameEl?.addEventListener('input', () => {
      if (previewName) previewName.textContent = (nameEl.value || 'NOMBRE APELLIDO').toUpperCase();
    });
  };

  const processPayment = async () => {
    const sm = cart.summary;
    // Render pantalla de procesamiento
    root.innerHTML = `
      <div class="processing">
        <div class="processing-spinner" aria-hidden="true"></div>
        <h3>Procesando tu pago</h3>
        <p>No cierres esta ventana — esto sólo tarda unos segundos.</p>
        <ol class="processing-steps" id="processing-steps">
          ${FakePaymentGateway.getSteps().map(s => `
            <li class="processing-step" data-step="${s.key}">
              <span class="step-mark">○</span> ${s.label}
            </li>
          `).join('')}
        </ol>
      </div>
    `;

    const gateway = new FakePaymentGateway();
    const result = await gateway.charge(
      { cardNumber: state.cardNumber, fullName: state.fullName, amount: sm.total },
      (key) => {
        const li = root.querySelector(`[data-step="${key}"]`);
        if (li) {
          li.classList.add('is-done');
          li.querySelector('.step-mark').innerHTML = '✓';
        }
      }
    );

    // Crear el pedido
    const order = orderService.placeOrder(
      cart,
      {
        fullName: state.fullName,
        email: state.email,
        phone: state.phone,
        address: state.address,
        city: state.city,
        notes: state.notes,
      },
      {
        method: state.method,
        brand: result.brand,
        last4: result.last4,
        transactionId: result.transactionId,
        authCode: result.authCode,
      }
    );

    // limpiar carrito y navegar al éxito
    cartService.clear();
    setTimeout(() => {
      location.hash = `#/success/${order.id}`;
    }, 600);
  };

  renderForm();
  return root;
}

// ===== Helpers internos de la vista =====

function renderMethod(id, label, isActive) {
  return `
    <label class="payment-method ${isActive ? 'is-active' : ''}" data-method="${id}">
      <input type="radio" name="method" value="${id}" ${isActive ? 'checked' : ''} />
      <span>${label}</span>
    </label>
  `;
}

function renderCardBlock(state) {
  return `
    <div class="cc-preview" aria-hidden="true">
      <div class="cc-row">
        <div class="cc-chip"></div>
        <div class="cc-brand">bazar · pay</div>
      </div>
      <div class="cc-number" id="cc-prev-num">•••• •••• •••• ••••</div>
      <div class="cc-bottom">
        <div>
          <div class="label">Titular</div>
          <div id="cc-prev-name">NOMBRE APELLIDO</div>
        </div>
        <div>
          <div class="label">Vence</div>
          <div id="cc-prev-exp">MM/AA</div>
        </div>
      </div>
    </div>

    <div class="form-grid">
      <label class="field full">
        <span class="field-label">Número de tarjeta</span>
        <input class="input" name="cardNumber" inputmode="numeric" autocomplete="cc-number" placeholder="0000 0000 0000 0000" required />
      </label>
      <label class="field full">
        <span class="field-label">Nombre del titular</span>
        <input class="input" name="cardName" autocomplete="cc-name" placeholder="Como aparece en la tarjeta" required />
      </label>
      <label class="field">
        <span class="field-label">Vencimiento</span>
        <input class="input" name="cardExp" inputmode="numeric" autocomplete="cc-exp" placeholder="MM/AA" required />
      </label>
      <label class="field">
        <span class="field-label">CVV</span>
        <input class="input" name="cardCvv" inputmode="numeric" autocomplete="cc-csc" placeholder="•••" required />
      </label>
    </div>
  `;
}

function readForm(form) {
  const data = {};
  new FormData(form).forEach((v, k) => data[k] = String(v).trim());
  return data;
}

function validate(state) {
  const errors = {};
  if (!state.fullName) errors.fullName = 'Requerido';
  if (!state.email || !/^\S+@\S+\.\S+$/.test(state.email)) errors.email = 'Email inválido';
  if (!state.phone) errors.phone = 'Requerido';
  if (!state.address) errors.address = 'Requerido';
  if (!state.city) errors.city = 'Requerido';

  if (state.method === 'card') {
    const num = (state.cardNumber || '').replace(/\s+/g, '');
    if (num.length < 12) errors.cardNumber = 'Número inválido';
    if (!state.cardName) errors.cardName = 'Requerido';
    if (!/^\d{2}\/\d{2}$/.test(state.cardExp || '')) errors.cardExp = 'MM/AA';
    if (!/^\d{3,4}$/.test(state.cardCvv || '')) errors.cardCvv = '3 ó 4 dígitos';
  }
  return errors;
}

function showErrors(form, errors) {
  // limpia errores anteriores
  form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
  Object.keys(errors).forEach(name => {
    const input = form.querySelector(`[name="${name}"]`);
    if (input) input.classList.add('is-invalid');
  });
}

function escape(s) {
  return String(s ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
}
