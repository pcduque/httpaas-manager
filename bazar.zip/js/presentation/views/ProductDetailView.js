/**
 * Capa: PRESENTACIÓN — vista
 * ProductDetailView — detalle de producto con galería, opciones y CTA.
 */
import { formatPrice } from '../format.js';
import { ImageResolver } from '../ImageResolver.js';
import { Toast } from '../Toast.js';

const STAR = `<svg viewBox="0 0 24 24"><path d="M12 2l2.6 6.5 7 .6-5.3 4.6 1.6 6.8L12 16.8 6.1 20.5l1.6-6.8L2.4 9.1l7-.6z"/></svg>`;

export function ProductDetailView({ catalog, cartService, productId }) {
  const product = catalog.getById(productId);
  const root = document.createElement('div');
  root.className = 'container';

  if (!product) {
    root.innerHTML = `
      <div class="empty-state">
        <h3>Producto no encontrado</h3>
        <p>El producto que buscas no existe o fue retirado.</p>
        <a class="btn btn-primary" href="#/">Volver al catálogo</a>
      </div>`;
    return root;
  }

  const gallery = ImageResolver.galleryFor(product.id);
  let selectedThumb = 0;
  let qty = 1;

  const render = () => {
    root.innerHTML = `
      <a href="#/" class="pd-back">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
        Volver al catálogo
      </a>
      <nav class="breadcrumb" aria-label="breadcrumb">
        <a href="#/">Tienda</a>
        <span class="crumb-sep">/</span>
        <span>${escape(product.category)}</span>
        <span class="crumb-sep">/</span>
        <span class="is-current">${escape(product.name)}</span>
      </nav>

      <article class="product-detail">
        <div class="pd-gallery">
          <div class="pd-gallery-main">
            <img id="pd-main-img" src="${gallery[selectedThumb]}" alt="${escape(product.name)}"
                 onerror="this.style.opacity=0.05" />
          </div>
          <div class="pd-gallery-thumbs">
            ${gallery.map((src, i) => `
              <button class="pd-thumb ${i === selectedThumb ? 'is-active' : ''}" data-thumb="${i}" type="button" aria-label="Imagen ${i+1}">
                <img src="${src}" alt="" />
              </button>
            `).join('')}
          </div>
        </div>

        <div class="pd-info">
          <p class="pd-vendor">${escape(product.vendor)} · ${escape(product.sku)}</p>
          <h1 class="pd-title">${escape(product.name)}</h1>

          <div class="pd-rating">
            <span class="stars">${STAR.repeat(5)}</span>
            <span><strong>${product.rating.toFixed(1)}</strong></span>
            <span class="reviews">· ${product.reviews} reseñas</span>
          </div>

          <div class="pd-price-row">
            <span class="pd-price">${formatPrice(product.price, product.currency)}</span>
            ${product.hasDiscount ? `
              <span class="pd-price-old">${formatPrice(product.oldPrice, product.currency)}</span>
              <span class="pd-discount">−${product.discountPercent}%</span>
            ` : ''}
          </div>

          <p class="pd-desc">${escape(product.description)}</p>

          <div class="pd-options">
            <div class="field" style="gap: var(--sp-2)">
              <span class="field-label">Cantidad</span>
              <div class="stepper" role="group" aria-label="Cantidad">
                <button type="button" id="qty-dec" aria-label="Disminuir">−</button>
                <span class="stepper-value" id="qty-val">${qty}</span>
                <button type="button" id="qty-inc" aria-label="Aumentar">+</button>
              </div>
            </div>
            <div class="field" style="gap: var(--sp-2)">
              <span class="field-label">Stock</span>
              <span class="badge-tag is-leaf" style="align-self: flex-start;">
                ${product.stock} disponibles
              </span>
            </div>
          </div>

          <div class="pd-actions">
            <button class="btn btn-accent btn-lg btn-block" id="add-to-cart" type="button">
              Añadir al carrito · ${formatPrice(product.price * qty, product.currency)}
            </button>
            <button class="btn btn-ghost btn-lg" id="buy-now" type="button">Comprar ya</button>
          </div>

          <ul class="pd-features">
            ${product.features.map(f => `
              <li class="pd-feature">
                <span class="icon">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13l4 4L19 7"/></svg>
                </span>
                <strong>Detalle</strong>
                <span>${escape(f)}</span>
              </li>
            `).join('')}
          </ul>
        </div>
      </article>
    `;

    // bind thumbs
    root.querySelectorAll('.pd-thumb').forEach(btn => {
      btn.addEventListener('click', () => {
        selectedThumb = Number(btn.dataset.thumb);
        const main = root.querySelector('#pd-main-img');
        if (main) main.src = gallery[selectedThumb];
        root.querySelectorAll('.pd-thumb').forEach(t => t.classList.remove('is-active'));
        btn.classList.add('is-active');
      });
    });

    // qty
    const qtyVal = root.querySelector('#qty-val');
    const cta = root.querySelector('#add-to-cart');
    const refreshCta = () => {
      qtyVal.textContent = qty;
      cta.textContent = `Añadir al carrito · ${formatPrice(product.price * qty, product.currency)}`;
    };
    root.querySelector('#qty-dec').addEventListener('click', () => { qty = Math.max(1, qty - 1); refreshCta(); });
    root.querySelector('#qty-inc').addEventListener('click', () => { qty = Math.min(product.stock || 99, qty + 1); refreshCta(); });

    cta.addEventListener('click', () => {
      cartService.addProduct(product, qty);
      Toast.success(`Añadido al carrito (×${qty})`);
    });
    root.querySelector('#buy-now').addEventListener('click', () => {
      cartService.addProduct(product, qty);
      location.hash = '#/checkout';
    });
  };

  render();
  return root;
}

function escape(s) {
  return String(s ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
}
