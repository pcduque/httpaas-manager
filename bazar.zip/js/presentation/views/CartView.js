/**
 * Capa: PRESENTACIÓN — vista
 * CartView — listado de items en el carrito + resumen + cupón
 */
import { formatPrice } from '../format.js';
import { ImageResolver } from '../ImageResolver.js';
import { Toast } from '../Toast.js';

export function CartView({ cartService }) {
  const root = document.createElement('div');
  root.className = 'container';
  let appliedCoupon = null;

  const render = () => {
    const cart = cartService.getCart();

    if (cart.isEmpty) {
      root.innerHTML = `
        <h1 style="margin-bottom: var(--sp-6); font-size: var(--fs-2xl);">Carrito</h1>
        <div class="empty-state">
          <div class="empty-icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8h14l-1 12H6L5 8zM9 8V6a3 3 0 0 1 6 0v2"/></svg>
          </div>
          <h3>Tu carrito está vacío</h3>
          <p>Aún no has añadido nada. Volvé al catálogo a curiosear.</p>
          <a class="btn btn-primary" href="#/">Explorar el bazar</a>
        </div>`;
      return;
    }

    const sm = cart.summary;

    root.innerHTML = `
      <header class="orders-header" style="margin-bottom: var(--sp-5);">
        <div>
          <p class="eyebrow">PASO 01 DE 03</p>
          <h1 style="font-size: var(--fs-2xl); margin-top: var(--sp-2);">Tu carrito</h1>
          <p class="subtitle">${cart.itemCount} producto${cart.itemCount === 1 ? '' : 's'} · revisá antes de continuar</p>
        </div>
        <button class="btn btn-ghost btn-sm" id="clear-cart" type="button">Vaciar carrito</button>
      </header>

      <div class="cart-page">
        <div class="cart-list">
          ${cart.items.map(item => renderCartItem(item)).join('')}
        </div>

        <aside class="summary-card" aria-labelledby="summary-title">
          <h3 id="summary-title">Resumen</h3>
          <div class="summary-row"><span>Subtotal</span><span class="price">${formatPrice(sm.subtotal)}</span></div>
          <div class="summary-row"><span>IVA estimado (incluido)</span><span class="price">${formatPrice(sm.taxes)}</span></div>
          <div class="summary-row">
            <span>Envío</span>
            <span class="price">
              ${sm.hasFreeShipping
                ? `<span class="badge-tag is-leaf">Gratis</span>`
                : formatPrice(sm.shippingCost)}
            </span>
          </div>
          ${!sm.hasFreeShipping ? `
            <p class="summary-help">
              Te faltan ${formatPrice(sm.shippingThreshold - sm.subtotal)} para envío gratis.
            </p>` : ''}

          <div class="summary-coupon">
            <input class="input" id="coupon-input" placeholder="Código de descuento" />
            <button class="btn btn-ghost btn-sm" id="apply-coupon" type="button">Aplicar</button>
          </div>

          <hr class="divider-rule" />
          <div class="summary-row is-total"><span>Total</span><span class="price">${formatPrice(sm.total)}</span></div>

          <a class="btn btn-accent btn-lg btn-block" href="#/checkout">
            Continuar al pago
          </a>
          <p class="summary-help">Pago simulado · sin servicios externos</p>
        </aside>
      </div>
    `;

    bindEvents();
  };

  const bindEvents = () => {
    root.querySelector('#clear-cart')?.addEventListener('click', () => {
      if (confirm('¿Vaciar el carrito?')) {
        cartService.clear();
        Toast.info('Carrito vaciado');
        render();
      }
    });

    root.querySelectorAll('[data-cart-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.id;
        const action = btn.dataset.cartAction;
        const cart = cartService.getCart();
        const item = cart.items.find(i => i.productId === id);
        if (!item) return;
        if (action === 'inc') cartService.changeQuantity(id, item.quantity + 1);
        if (action === 'dec') cartService.changeQuantity(id, item.quantity - 1);
        if (action === 'remove') {
          cartService.removeProduct(id);
          Toast.info('Producto retirado');
        }
        render();
      });
    });

    root.querySelector('#apply-coupon')?.addEventListener('click', () => {
      const code = root.querySelector('#coupon-input').value.trim().toUpperCase();
      if (!code) return;
      appliedCoupon = code;
      Toast.info(`El código "${code}" se mostraría aquí (simulado)`);
    });
  };

  render();
  return root;
}

function renderCartItem(item) {
  const img = ImageResolver.pathFor(item.productId);
  return `
    <div class="cart-item" data-id="${escape(item.productId)}">
      <div class="cart-item-thumb">
        <img src="${img}" alt="${escape(item.name)}" onerror="this.style.opacity=.1" />
      </div>
      <div class="cart-item-body">
        <span class="cart-item-vendor">${escape(item.vendor)}</span>
        <h4 class="cart-item-name">${escape(item.name)}</h4>
        <div class="cart-item-controls">
          <div class="stepper" role="group">
            <button type="button" data-cart-action="dec" data-id="${escape(item.productId)}"
                    ${item.quantity <= 1 ? 'disabled' : ''} aria-label="Disminuir">−</button>
            <span class="stepper-value">${item.quantity}</span>
            <button type="button" data-cart-action="inc" data-id="${escape(item.productId)}" aria-label="Aumentar">+</button>
          </div>
          <button type="button" class="cart-item-remove" data-cart-action="remove" data-id="${escape(item.productId)}">
            Quitar
          </button>
        </div>
      </div>
      <div class="cart-item-pricing">
        <span class="cart-item-subtotal">${formatPrice(item.subtotal)}</span>
        <span class="cart-item-unit">${formatPrice(item.unitPrice)} c/u</span>
      </div>
    </div>
  `;
}

function escape(s) {
  return String(s ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
}
