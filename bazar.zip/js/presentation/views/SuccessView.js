/**
 * Capa: PRESENTACIÓN — vista
 * SuccessView — pantalla de confirmación post-pago.
 * Recibe el orderId por param de ruta, lo recupera del OrderService
 * y muestra resumen + CTAs.
 */
import { formatPrice, formatDate, escapeHtml } from '../format.js';

export function SuccessView({ orderService, orderId }) {
  const root = document.createElement('div');
  root.className = 'container';

  const order = orderService.getById(orderId);

  if (!order) {
    root.innerHTML = `
      <div class="empty-state">
        <h3>No encontramos ese pedido</h3>
        <p>El identificador <code>${escapeHtml(orderId)}</code> no figura en tu historial.</p>
        <a class="btn btn-primary" href="#/orders">Ver mis pedidos</a>
      </div>`;
    return root;
  }

  const customerName = order.customer?.name || 'cliente';
  const customerEmail = order.customer?.email || '';
  const brand = order.payment?.brand || '—';
  const last4 = order.payment?.last4 || '••••';

  root.innerHTML = `
    <div class="success-screen">
      <div class="success-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
             stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
      </div>

      <h2>¡Gracias por tu compra, ${escapeHtml(customerName.split(' ')[0])}!</h2>
      <p style="color: var(--muted); max-width: 480px; margin: 0 auto;">
        Tu pedido fue confirmado y está siendo preparado. Te enviamos los detalles
        ${customerEmail ? `a <strong>${escapeHtml(customerEmail)}</strong>` : 'a tu correo'}.
      </p>

      <div class="order-id">${escapeHtml(order.id)}</div>

      <div class="order-meta-grid" style="max-width: 560px; margin: 0 auto;">
        <div>
          <div class="label">Total</div>
          <div class="value" style="font-family: var(--font-mono);">
            ${formatPrice(order.total)}
          </div>
        </div>
        <div>
          <div class="label">Items</div>
          <div class="value" style="font-family: var(--font-mono);">
            ${order.itemCount}
          </div>
        </div>
        <div>
          <div class="label">Pago</div>
          <div class="value" style="font-family: var(--font-mono);">
            ${escapeHtml(brand)} ····${escapeHtml(last4)}
          </div>
        </div>
      </div>

      <p style="color: var(--muted); font-size: var(--fs-sm); margin-top: var(--sp-5);">
        Confirmado el ${escapeHtml(formatDate(order.createdAt))}
      </p>

      <div class="success-actions">
        <a class="btn btn-primary" href="#/orders">Ver mis pedidos</a>
        <a class="btn btn-ghost" href="#/">Seguir comprando</a>
      </div>
    </div>
  `;

  return root;
}
