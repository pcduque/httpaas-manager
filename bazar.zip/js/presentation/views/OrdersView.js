/**
 * Capa: PRESENTACIÓN — vista
 * OrdersView — historial de pedidos del usuario, con detalle expandible.
 */
import { formatPrice, formatDate, escapeHtml } from '../format.js';
import { ImageResolver } from '../ImageResolver.js';

export function OrdersView({ orderService }) {
  const root = document.createElement('div');
  root.className = 'container';

  const orders = orderService.getHistory()
    .slice()
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  if (orders.length === 0) {
    root.innerHTML = `
      <div class="orders-header">
        <div>
          <h1>Mis pedidos</h1>
          <p class="subtitle">Aquí aparecerán todas tus compras.</p>
        </div>
      </div>
      <div class="empty-state">
        <div class="empty-icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none"
               stroke="currentColor" stroke-width="1.5"
               stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 7h18l-1.5 13H4.5L3 7z"/>
            <path d="M8 7V5a4 4 0 0 1 8 0v2"/>
          </svg>
        </div>
        <h3>Todavía no hay pedidos</h3>
        <p>Cuando hagas tu primera compra, aparecerá listada aquí.</p>
        <a class="btn btn-primary" href="#/">Explorar el bazar</a>
      </div>
    `;
    return root;
  }

  const renderThumbs = (items) => {
    const visible = items.slice(0, 4);
    const extra = items.length - visible.length;
    const thumbsHtml = visible.map(item => {
      const src = ImageResolver.pathFor(item.productId);
      return `
        <div class="thumb">
          <img src="${escapeHtml(src)}"
               alt="${escapeHtml(item.name)}"
               onerror="this.style.display='none'; this.parentElement.style.background='var(--paper-soft)'"/>
        </div>`;
    }).join('');
    const more = extra > 0 ? `<div class="more">+${extra}</div>` : '';
    return thumbsHtml + more;
  };

  const renderProducts = (items) => items.map(item => {
    const src = ImageResolver.pathFor(item.productId);
    return `
      <div class="order-product-row">
        <div class="thumb">
          <img src="${escapeHtml(src)}"
               alt="${escapeHtml(item.name)}"
               onerror="this.style.display='none'"/>
        </div>
        <div class="name">${escapeHtml(item.name)}</div>
        <div class="qty">× ${item.quantity}</div>
        <div class="subtotal">${formatPrice(item.price * item.quantity)}</div>
      </div>
    `;
  }).join('');

  const renderOrderCard = (order) => {
    const brand = order.payment?.brand || '—';
    const last4 = order.payment?.last4 || '••••';
    const txId = order.payment?.transactionId || '—';
    const authCode = order.payment?.authCode || '—';
    const customerName = order.customer?.name || '—';
    const customerEmail = order.customer?.email || '';
    const customerCity = order.customer?.city || '';

    return `
      <article class="order-card" data-order-id="${escapeHtml(order.id)}">
        <header class="order-card-head">
          <div class="order-id-block">
            <div class="label">Pedido</div>
            <div class="id">${escapeHtml(order.id)}</div>
          </div>
          <div class="order-status is-${escapeHtml(order.status)}">${escapeHtml(order.status)}</div>
          <div class="order-date">${escapeHtml(formatDate(order.createdAt))}</div>
        </header>

        <div class="order-card-body">
          <div class="order-thumbs">
            ${renderThumbs(order.items)}
          </div>
          <div class="order-summary">
            <div class="label">Total</div>
            <div class="total">${formatPrice(order.total)}</div>
          </div>
        </div>

        <div class="order-card-detail">
          <div class="order-products">
            ${renderProducts(order.items)}
          </div>

          <div class="order-meta-grid">
            <div>
              <div class="label">Cliente</div>
              <div class="value">${escapeHtml(customerName)}</div>
              ${customerEmail ? `<div class="value" style="font-weight: 400; color: var(--muted); font-size: var(--fs-xs); margin-top: 2px;">${escapeHtml(customerEmail)}</div>` : ''}
              ${customerCity ? `<div class="value" style="font-weight: 400; color: var(--muted); font-size: var(--fs-xs);">${escapeHtml(customerCity)}</div>` : ''}
            </div>
            <div>
              <div class="label">Pago</div>
              <div class="value">${escapeHtml(brand)} ····${escapeHtml(last4)}</div>
              <div class="value" style="font-weight: 400; color: var(--muted); font-size: var(--fs-xs); margin-top: 2px; font-family: var(--font-mono);">
                AUTH ${escapeHtml(authCode)}
              </div>
            </div>
            <div>
              <div class="label">Transacción</div>
              <div class="value" style="font-family: var(--font-mono); font-size: var(--fs-xs); word-break: break-all;">
                ${escapeHtml(txId)}
              </div>
            </div>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: var(--sp-3); margin-top: var(--sp-4); font-family: var(--font-mono); font-size: var(--fs-xs); color: var(--muted);">
            <div>Subtotal: <strong style="color: var(--ink);">${formatPrice(order.subtotal)}</strong></div>
            <div>Envío: <strong style="color: var(--ink);">${order.shippingCost === 0 ? 'gratis' : formatPrice(order.shippingCost)}</strong></div>
            <div>IVA: <strong style="color: var(--ink);">${formatPrice(order.taxes)}</strong></div>
          </div>
        </div>

        <div style="padding: 0 var(--sp-5) var(--sp-4); display: flex; justify-content: flex-end;">
          <button class="order-toggle" data-toggle="${escapeHtml(order.id)}">
            <span class="toggle-label">Ver detalle</span>
            <span class="chevron">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none"
                   stroke="currentColor" stroke-width="2.5"
                   stroke-linecap="round" stroke-linejoin="round">
                <polyline points="6 9 12 15 18 9"/>
              </svg>
            </span>
          </button>
        </div>
      </article>
    `;
  };

  root.innerHTML = `
    <div class="orders-header">
      <div>
        <h1>Mis pedidos</h1>
        <p class="subtitle">${orders.length} pedido${orders.length === 1 ? '' : 's'} en tu historial</p>
      </div>
      <a class="btn btn-ghost" href="#/">Seguir comprando</a>
    </div>

    <div class="orders-list">
      ${orders.map(renderOrderCard).join('')}
    </div>
  `;

  // Toggle de detalle
  root.addEventListener('click', (ev) => {
    const btn = ev.target.closest('[data-toggle]');
    if (!btn) return;
    const card = btn.closest('.order-card');
    if (!card) return;
    const isOpen = card.classList.toggle('is-open');
    const label = btn.querySelector('.toggle-label');
    if (label) label.textContent = isOpen ? 'Ocultar detalle' : 'Ver detalle';
  });

  return root;
}
