/**
 * Capa: PRESENTACIÓN — vista
 * CatalogView — listado del catálogo + filtros + hero
 */
import { html } from '../format.js';
import { renderProductCard } from '../components/ProductCard.js';
import { Toast } from '../Toast.js';
import { Router } from '../Router.js';

export function CatalogView({ catalog, cartService }) {
  // estado local de la vista
  let activeCategory = 'all';
  let query = '';

  const root = document.createElement('div');
  root.className = 'container';

  const products = () => catalog.list({ category: activeCategory, query });
  const allProducts = catalog.list();

  const heroStats = {
    products: allProducts.length,
    artisans: new Set(allProducts.map(p => p.vendor)).size,
  };

  const render = () => {
    const list = products();
    root.innerHTML = `
      <section class="hero">
        <div class="hero-inner">
          <div>
            <p class="eyebrow hero-eyebrow">EDICIÓN MAYO · 2026</p>
            <h1 class="hero-headline">
              Objetos lentos<br/>
              para casas <em>despiertas</em>.<br/>
              <span class="stroke">Bazar</span> de autor.
            </h1>
            <p class="hero-sub">
              Una pieza didáctica de e-commerce — sin backend, sin terceros.
              Curaduría imaginaria de talleres independientes.
            </p>
          </div>
          <div class="hero-meta">
            <div class="hero-meta-item">
              <div class="label">Productos</div>
              <div class="value">${heroStats.products}</div>
            </div>
            <div class="hero-meta-item">
              <div class="label">Talleres</div>
              <div class="value">${heroStats.artisans}</div>
            </div>
            <div class="hero-meta-item">
              <div class="label">Envío gratis desde</div>
              <div class="value">$ 200.000</div>
            </div>
            <div class="hero-meta-item">
              <div class="label">Cambios</div>
              <div class="value">15 días</div>
            </div>
          </div>
        </div>
      </section>

      <div class="catalog-bar">
        <div class="catalog-title">
          <h2>Catálogo</h2>
          <span class="count">${list.length} resultado${list.length === 1 ? '' : 's'}</span>
        </div>
        <div class="chips" role="tablist" aria-label="Filtrar por categoría">
          ${catalog.getCategories().map(c => `
            <button class="chip ${c.id === activeCategory ? 'is-active' : ''}"
                    data-cat="${c.id}" role="tab" aria-selected="${c.id === activeCategory}">
              ${c.label}
            </button>
          `).join('')}
        </div>
      </div>

      <div class="product-grid" id="catalog-grid">
        ${list.map(renderProductCard).join('')}
      </div>

      ${list.length === 0 ? `
        <div class="empty-state" style="margin-top: var(--sp-5);">
          <div class="empty-icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3" stroke-linecap="round"/></svg>
          </div>
          <h3>Sin resultados</h3>
          <p>No encontramos productos en esta categoría.</p>
        </div>
      ` : ''}
    `;

    // bind filtros
    root.querySelectorAll('.chip').forEach(chip => {
      chip.addEventListener('click', () => {
        activeCategory = chip.dataset.cat;
        render();
      });
    });

    // bind cards: click en card -> detalle, click en botón "+" -> add directo
    root.querySelectorAll('.product-card').forEach(card => {
      const id = card.dataset.productId;
      card.addEventListener('click', (e) => {
        const action = e.target.closest('[data-action]')?.dataset.action;
        if (action === 'add') {
          e.preventDefault(); e.stopPropagation();
          const product = catalog.getById(id);
          cartService.addProduct(product, 1);
          Toast.success(`${product.name.split('·')[0].trim()} añadido al carrito`);
          return;
        }
        if (action === 'favorite') {
          e.preventDefault(); e.stopPropagation();
          e.target.closest('.product-fav').classList.toggle('is-active');
          return;
        }
        // navegar al detalle
        location.hash = `#/product/${id}`;
      });
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') location.hash = `#/product/${id}`;
      });
    });
  };

  render();
  return root;
}
