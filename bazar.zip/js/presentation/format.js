/**
 * Capa: PRESENTACIÓN — utilidades
 * format.js: formateo de moneda, fechas y helpers HTML
 */
const CURRENCY = 'COP';

export function formatPrice(value, currency = CURRENCY) {
  try {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  } catch {
    return `$ ${Math.round(value).toLocaleString('es-CO')}`;
  }
}

export function formatDate(iso) {
  try {
    const d = new Date(iso);
    return new Intl.DateTimeFormat('es-CO', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit',
    }).format(d);
  } catch {
    return iso;
  }
}

/** Sanitiza para insertar en HTML. */
export function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

/** Tagged template para construir HTML escapando interpolaciones por defecto.
 *  Si querés inyectar HTML crudo: { __html: '...' } */
export function html(strings, ...values) {
  let out = '';
  strings.forEach((str, i) => {
    out += str;
    if (i < values.length) {
      const v = values[i];
      if (v === null || v === undefined || v === false) {
        out += '';
      } else if (Array.isArray(v)) {
        out += v.join('');
      } else if (typeof v === 'object' && v && '__html' in v) {
        out += v.__html;
      } else {
        out += escapeHtml(v);
      }
    }
  });
  return out;
}
