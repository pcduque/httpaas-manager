/**
 * Capa: PRESENTACIÓN
 * Router — hash router minimalista para la SPA.
 *
 * Rutas:
 *   #/                  -> Catálogo (home)
 *   #/product/:id       -> Detalle producto
 *   #/cart              -> Carrito
 *   #/checkout          -> Pasarela de pago
 *   #/success/:orderId  -> Confirmación
 *   #/orders            -> Historial
 *
 * Cada ruta es una función `(params) => HTMLElement | string` ejecutada al hacer match.
 */
export class Router {
  constructor(rootEl) {
    this.root = rootEl;
    this._routes = [];
    this._notFound = () => `<div class="container"><h2>404</h2></div>`;
    this._before = null;
  }

  on(pattern, handler) {
    const { regex, keys } = this._compile(pattern);
    this._routes.push({ pattern, regex, keys, handler });
    return this;
  }

  notFound(handler) { this._notFound = handler; return this; }
  before(fn) { this._before = fn; return this; }

  start() {
    window.addEventListener('hashchange', () => this._resolve());
    window.addEventListener('popstate', () => this._resolve());
    this._resolve();
  }

  navigate(path) {
    if (location.hash === `#${path}`) {
      this._resolve(); // re-render mismo path
    } else {
      location.hash = path;
    }
  }

  static link(path) { return `#${path}`; }

  _compile(pattern) {
    const keys = [];
    const rx = pattern
      .replace(/\//g, '\\/')
      .replace(/:([\w]+)/g, (_, k) => { keys.push(k); return '([^\\/]+)'; });
    return { regex: new RegExp(`^${rx}$`), keys };
  }

  async _resolve() {
    const hash = (location.hash || '#/').slice(1) || '/';
    if (this._before) this._before(hash);

    for (const r of this._routes) {
      const m = hash.match(r.regex);
      if (m) {
        const params = {};
        r.keys.forEach((k, i) => params[k] = decodeURIComponent(m[i + 1]));
        await this._render(() => r.handler(params));
        return;
      }
    }
    await this._render(() => this._notFound());
  }

  async _render(fn) {
    this.root.innerHTML = '';
    const result = await fn();
    if (result == null) return;
    if (typeof result === 'string') {
      this.root.innerHTML = result;
    } else if (result instanceof Node) {
      this.root.appendChild(result);
    }
    // scroll al tope al cambiar de ruta
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
  }
}
