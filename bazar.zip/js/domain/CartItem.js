/**
 * Capa: DOMINIO
 * CartItem - Item dentro del carrito. Snapshot del producto al momento de añadirlo.
 */
export class CartItem {
  constructor({ productId, name, vendor, unitPrice, quantity = 1 }) {
    if (!productId) throw new Error('CartItem: productId requerido');
    if (quantity < 1) throw new Error('CartItem: quantity debe ser >= 1');
    if (unitPrice < 0) throw new Error('CartItem: unitPrice no puede ser negativo');

    this.productId = productId;
    this.name = name;
    this.vendor = vendor;
    this.unitPrice = unitPrice;
    this.quantity = quantity;
  }

  get subtotal() {
    return this.unitPrice * this.quantity;
  }

  withQuantity(qty) {
    return new CartItem({
      productId: this.productId,
      name: this.name,
      vendor: this.vendor,
      unitPrice: this.unitPrice,
      quantity: qty,
    });
  }

  toJSON() {
    return { ...this };
  }
}
