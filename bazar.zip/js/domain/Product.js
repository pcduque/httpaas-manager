/**
 * Capa: DOMINIO
 * Entidad Producto. Inmutable, sin dependencias externas.
 * Encapsula reglas: precio nunca negativo, stock nunca negativo, descuento entre 0 y 100.
 */
export class Product {
  constructor({
    id, sku, name, vendor, category,
    price, oldPrice = null, currency = 'COP',
    rating = 0, reviews = 0, stock = 0,
    description = '', features = [],
    tag = null
  }) {
    if (!id) throw new Error('Product: id requerido');
    if (!name) throw new Error('Product: name requerido');
    if (price < 0) throw new Error('Product: price no puede ser negativo');
    if (stock < 0) throw new Error('Product: stock no puede ser negativo');

    this.id = id;
    this.sku = sku;
    this.name = name;
    this.vendor = vendor;
    this.category = category;
    this.price = price;
    this.oldPrice = oldPrice;
    this.currency = currency;
    this.rating = rating;
    this.reviews = reviews;
    this.stock = stock;
    this.description = description;
    this.features = features;
    this.tag = tag;
    Object.freeze(this);
  }

  get hasDiscount() {
    return this.oldPrice !== null && this.oldPrice > this.price;
  }

  get discountPercent() {
    if (!this.hasDiscount) return 0;
    return Math.round(((this.oldPrice - this.price) / this.oldPrice) * 100);
  }

  get isAvailable() {
    return this.stock > 0;
  }
}
