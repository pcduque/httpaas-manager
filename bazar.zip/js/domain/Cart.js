/**
 * Capa: DOMINIO
 * Cart — Agregado raíz para el carrito de compras.
 * Reglas de negocio:
 *   - Cantidad máxima por producto: 99
 *   - Carrito vacío no puede ser confirmado
 *   - Costos derivados: subtotal, envío, impuestos, total
 */
import { CartItem } from './CartItem.js';

const MAX_QUANTITY = 99;
const FREE_SHIPPING_THRESHOLD = 200000;
const SHIPPING_COST = 12000;
const TAX_RATE = 0.19; // IVA 19% — sólo para mostrar, valor educativo

export class Cart {
  constructor(items = []) {
    this.items = items.map(i => i instanceof CartItem ? i : new CartItem(i));
  }

  static empty() {
    return new Cart([]);
  }

  addItem(item) {
    const existing = this.items.find(i => i.productId === item.productId);
    if (existing) {
      const newQty = Math.min(existing.quantity + item.quantity, MAX_QUANTITY);
      const updated = existing.withQuantity(newQty);
      return new Cart(this.items.map(i => i === existing ? updated : i));
    }
    return new Cart([...this.items, item]);
  }

  removeItem(productId) {
    return new Cart(this.items.filter(i => i.productId !== productId));
  }

  setQuantity(productId, qty) {
    const safeQty = Math.max(1, Math.min(qty, MAX_QUANTITY));
    return new Cart(
      this.items.map(i => i.productId === productId ? i.withQuantity(safeQty) : i)
    );
  }

  clear() {
    return Cart.empty();
  }

  get itemCount() {
    return this.items.reduce((acc, i) => acc + i.quantity, 0);
  }

  get isEmpty() {
    return this.items.length === 0;
  }

  get subtotal() {
    return this.items.reduce((acc, i) => acc + i.subtotal, 0);
  }

  get shippingCost() {
    if (this.isEmpty) return 0;
    return this.subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_COST;
  }

  get taxes() {
    return Math.round(this.subtotal * TAX_RATE);
  }

  get total() {
    return this.subtotal + this.shippingCost;
  }

  get summary() {
    return {
      itemCount: this.itemCount,
      subtotal: this.subtotal,
      shippingCost: this.shippingCost,
      taxes: this.taxes,
      total: this.total,
      hasFreeShipping: this.shippingCost === 0 && !this.isEmpty,
      shippingThreshold: FREE_SHIPPING_THRESHOLD,
    };
  }

  toJSON() {
    return { items: this.items.map(i => i.toJSON()) };
  }
}
