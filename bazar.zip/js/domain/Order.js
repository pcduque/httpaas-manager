/**
 * Capa: DOMINIO
 * Order — Pedido confirmado. Inmutable.
 */
const STATUSES = ['paid', 'preparing', 'shipped', 'delivered', 'cancelled'];

export class Order {
  constructor({
    id, createdAt, items, customer, payment,
    subtotal, shippingCost, taxes, total,
    status = 'paid'
  }) {
    if (!id) throw new Error('Order: id requerido');
    if (!Array.isArray(items) || items.length === 0)
      throw new Error('Order: requiere al menos un item');
    if (!STATUSES.includes(status))
      throw new Error(`Order: status inválido (${status})`);

    this.id = id;
    this.createdAt = createdAt || new Date().toISOString();
    this.items = items;
    this.customer = customer;
    this.payment = payment;
    this.subtotal = subtotal;
    this.shippingCost = shippingCost;
    this.taxes = taxes;
    this.total = total;
    this.status = status;
    Object.freeze(this);
  }

  get itemCount() {
    return this.items.reduce((acc, i) => acc + i.quantity, 0);
  }

  /**
   * Genera un identificador legible y único basado en timestamp y random.
   * Formato: BZR-XXXXXX-YY
   */
  static generateId() {
    const ts = Date.now().toString(36).toUpperCase().slice(-6);
    const rnd = Math.floor(Math.random() * 100).toString().padStart(2, '0');
    return `BZR-${ts}-${rnd}`;
  }

  toJSON() {
    return {
      id: this.id,
      createdAt: this.createdAt,
      items: this.items,
      customer: this.customer,
      payment: this.payment,
      subtotal: this.subtotal,
      shippingCost: this.shippingCost,
      taxes: this.taxes,
      total: this.total,
      status: this.status,
    };
  }
}
