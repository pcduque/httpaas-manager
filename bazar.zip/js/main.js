/**
 * Capa: PRESENTACIÓN — entry point
 * main.js — bootstrap de la SPA. Compone las capas (infra → aplicación → presentación)
 * por inyección manual de dependencias (sin frameworks ni contenedores).
 */

// Infraestructura
import { ProductRepository } from './infrastructure/ProductRepository.js';
import { CartRepository } from './infrastructure/CartRepository.js';
import { OrderRepository } from './infrastructure/OrderRepository.js';

// Aplicación (casos de uso)
import { ProductCatalog } from './application/ProductCatalog.js';
import { CartService } from './application/CartService.js';
import { OrderService } from './application/OrderService.js';

// Presentación
import { Router } from './presentation/Router.js';
import { renderHeader } from './presentation/components/Header.js';

// Vistas
import { CatalogView } from './presentation/views/CatalogView.js';
import { ProductDetailView } from './presentation/views/ProductDetailView.js';
import { CartView } from './presentation/views/CartView.js';
import { CheckoutView } from './presentation/views/CheckoutView.js';
import { SuccessView } from './presentation/views/SuccessView.js';
import { OrdersView } from './presentation/views/OrdersView.js';

/* -------------------------------------------------------------- *
 *  Composición de dependencias                                   *
 * -------------------------------------------------------------- */
const productRepo = new ProductRepository();
const cartRepo = new CartRepository();
const orderRepo = new OrderRepository();

const catalog = new ProductCatalog(productRepo);
const cartService = new CartService(cartRepo);
const orderService = new OrderService(orderRepo);

/* -------------------------------------------------------------- *
 *  Header dinámico (badge del carrito reactivo)                  *
 * -------------------------------------------------------------- */
renderHeader(cartService);

/* -------------------------------------------------------------- *
 *  Footer — año dinámico                                          *
 * -------------------------------------------------------------- */
const yearEl = document.getElementById('footer-year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

/* -------------------------------------------------------------- *
 *  Routing                                                        *
 * -------------------------------------------------------------- */
const viewRoot = document.getElementById('view-root');
const router = new Router(viewRoot);

router
  .on('/', () => CatalogView({ catalog, cartService }))
  .on('/product/:id', (params) => ProductDetailView({
    catalog,
    cartService,
    productId: params.id,
  }))
  .on('/cart', () => CartView({ cartService }))
  .on('/checkout', () => CheckoutView({ cartService, orderService, router }))
  .on('/success/:orderId', (params) => SuccessView({
    orderService,
    orderId: params.orderId,
  }))
  .on('/orders', () => OrdersView({ orderService }))
  .notFound(() => {
    const el = document.createElement('div');
    el.className = 'container';
    el.innerHTML = `
      <div class="empty-state">
        <h3>Página no encontrada</h3>
        <p>La ruta solicitada no existe en el bazar.</p>
        <a class="btn btn-primary" href="#/">Volver al inicio</a>
      </div>`;
    return el;
  });

router.start();

/* Exponemos referencias mínimas en debug (útil al inspeccionar la VM) */
if (typeof window !== 'undefined') {
  window.__bazar = { catalog, cartService, orderService, router };
}
