================================================================
  BAZAR — Carpeta de imágenes de producto
================================================================

Colocá aquí 6 archivos PNG con estos nombres exactos:

    imagen1.png
    imagen2.png
    imagen3.png
    imagen4.png
    imagen5.png
    imagen6.png

REQUISITOS
----------
- Formato: PNG
- Todas las imágenes deben tener EL MISMO width y height entre sí
  (no hace falta un tamaño específico, pero deben ser uniformes
   para que las cards rendericen homogéneo).
- Recomendado: 800 × 1000 px (ratio 4:5) o 1000 × 1000 px (cuadrado).
- Las imágenes se ajustan a la card usando `object-fit: cover` en CSS,
  por lo que se centran automáticamente sin deformarse.

CÓMO SE USAN
------------
- El sistema (presentation/ImageResolver.js) asigna una de las 6 imágenes
  a cada producto de forma pseudo-aleatoria pero ESTABLE durante la sesión:
  un mismo producto siempre muestra la misma foto mientras dure la pestaña.
- En el detalle del producto se muestra una galería con 4 fotos (la
  principal + otras 3 rotadas), también extraídas de este conjunto.

NOTA
----
Si falta alguna imagen, la card cae a un fondo color papel con
gracia (manejado por el atributo onerror de cada <img>). Para una
demo limpia, asegurate de tener las 6.
