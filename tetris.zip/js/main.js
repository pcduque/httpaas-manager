/**
 * Capa: PRESENTACIÓN — entry point
 * main.js — bootstrap de la app. Compone las capas (infra → aplicación →
 * presentación) por inyección manual de dependencias.
 */

// Aplicación
import { GameEngine } from './application/GameEngine.js';

// Infraestructura
import { HighScoreRepository } from './infrastructure/HighScoreRepository.js';
import { InputAdapter } from './infrastructure/InputAdapter.js';

// Presentación
import { Renderer } from './presentation/Renderer.js';
import { PreviewRenderer } from './presentation/PreviewRenderer.js';
import { HudView } from './presentation/HudView.js';
import { ModalManager } from './presentation/Modal.js';
import { Toast } from './presentation/Toast.js';
import { renderHeader } from './presentation/components/Header.js';
import { lineClearLabel } from './domain/Scoring.js';

/* -------------------------------------------------------------- *
 *  DOM refs                                                       *
 * -------------------------------------------------------------- */
const $ = (id) => document.getElementById(id);

const headerEl    = $('app-header');
const boardCanvas = $('board-canvas');
const boardFrame  = $('board-frame');
const nextCanvas  = $('next-canvas');
const holdCanvas  = $('hold-canvas');

const scoreEl     = $('hud-score');
const linesEl     = $('hud-lines');
const levelEl     = $('hud-level');
const statusEl    = $('hud-status');
const highscoreEl = $('hud-highscore');
const scoresListEl= $('hud-scores-list');

const btnStart    = $('btn-start');
const btnPause    = $('btn-pause');
const btnRestart  = $('btn-restart');
const btnClearScores = $('btn-clear-scores');

const modalRoot   = $('modal-root');

const yearEl      = $('footer-year');

/* -------------------------------------------------------------- *
 *  Construcción de dependencias                                  *
 * -------------------------------------------------------------- */
const highScoreRepo = new HighScoreRepository();
const engine = new GameEngine();

const renderer = new Renderer(boardCanvas);
const nextPreview = new PreviewRenderer(nextCanvas);
const holdPreview = new PreviewRenderer(holdCanvas);

const hud = new HudView({
  scoreEl, linesEl, levelEl, statusEl, highscoreEl, scoresListEl,
});

const modal = new ModalManager(modalRoot);

/* -------------------------------------------------------------- *
 *  Header & footer                                                *
 * -------------------------------------------------------------- */
renderHeader(headerEl);
if (yearEl) yearEl.textContent = new Date().getFullYear();

/* -------------------------------------------------------------- *
 *  Pinta inicial                                                   *
 * -------------------------------------------------------------- */
function pushHighScores(currentScore = null) {
  hud.renderHighScores(highScoreRepo.loadAll(), currentScore);
}

function syncBoard(snapshot) {
  renderer.draw(snapshot);
  nextPreview.draw(snapshot.next);
  // Hold con dim si ya fue usado este turno
  holdPreview.dim = engine.holdUsedThisTurn;
  holdPreview.draw(snapshot.hold ? snapshot.hold.id : null);
  hud.update(snapshot);
}

// Snapshot vacío inicial
syncBoard(engine.snapshot());
pushHighScores();

/* -------------------------------------------------------------- *
 *  Suscripción a eventos del engine                              *
 * -------------------------------------------------------------- */
engine.on('state', syncBoard);

engine.on('lock', ({ rowsCleared, label }) => {
  if (rowsCleared > 0) {
    boardFrame.classList.remove('is-flash');
    void boardFrame.offsetWidth;
    boardFrame.classList.add('is-flash');
    if (label) {
      Toast.show(label.toUpperCase(), { tone: rowsCleared === 4 ? 'accent' : 'leaf' });
    }
  } else {
    boardFrame.classList.remove('is-shake');
    void boardFrame.offsetWidth;
    boardFrame.classList.add('is-shake');
  }
});

engine.on('levelup', ({ level }) => {
  Toast.show(`NIVEL ${level}`, { tone: 'gold' });
});

engine.on('pause', () => {
  modal.showPause({
    onResume: () => engine.resume(),
    onRestart: () => {
      engine.restart();
      Toast.show('Nueva partida', { tone: 'leaf' });
    },
  });
});

engine.on('resume', () => modal.close());

engine.on('gameover', ({ score, lines, level }) => {
  const isHigh = highScoreRepo.qualifies(score);
  modal.showGameOver({
    score, lines, level, isHighScore: isHigh,
    onRestart: () => {
      pushHighScores();
      engine.restart();
    },
    onSaveScore: (name) => {
      const { list, position } = highScoreRepo.add({ name, score, lines, level });
      hud.renderHighScores(list, score);
      if (position) {
        Toast.show(`Guardado en el puesto ${position}`, { tone: 'gold' });
      }
      engine.restart();
    },
  });
});

/* -------------------------------------------------------------- *
 *  Botones                                                         *
 * -------------------------------------------------------------- */
btnStart && btnStart.addEventListener('click', () => {
  if (engine.status === 'idle' || engine.status === 'over') {
    engine.start();
  } else if (engine.status === 'paused') {
    engine.resume();
  }
});

btnPause && btnPause.addEventListener('click', () => engine.togglePause());

btnRestart && btnRestart.addEventListener('click', () => {
  engine.restart();
  Toast.show('Nueva partida', { tone: 'leaf' });
});

btnClearScores && btnClearScores.addEventListener('click', () => {
  if (confirm('¿Borrar el top 5 de puntajes? Esta acción no se puede deshacer.')) {
    highScoreRepo.clear();
    pushHighScores();
    Toast.show('Puntajes borrados', { tone: 'accent' });
  }
});

/* -------------------------------------------------------------- *
 *  Input                                                           *
 * -------------------------------------------------------------- */
const input = new InputAdapter(engine, {
  onTogglePause: () => engine.togglePause(),
  onRestart: () => engine.restart(),
});
input.attach();

/* -------------------------------------------------------------- *
 *  Debug                                                           *
 * -------------------------------------------------------------- */
if (typeof window !== 'undefined') {
  window.__tetra = { engine, highScoreRepo };
}
