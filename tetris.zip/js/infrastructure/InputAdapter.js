/**
 * Capa: INFRAESTRUCTURA
 * InputAdapter — Captura teclado y dispara comandos del engine.
 *
 * Mapeo:
 *   ← / →  : moveLeft / moveRight   (auto-repeat por el navegador)
 *   ↓      : softDrop                (repeat ok)
 *   ↑ / X  : rotate horario
 *   Z / Ctrl: rotate antihorario
 *   Espacio: hardDrop                (NO repeat — sólo en keydown inicial)
 *   Shift / C: hold                  (NO repeat)
 *   P / Esc: togglePause
 *   Enter  : reiniciar (sólo si game over)
 */
export class InputAdapter {
  constructor(engine, { onRestart, onTogglePause } = {}) {
    this.engine = engine;
    this.onRestart = onRestart;
    this.onTogglePause = onTogglePause;
    this._handler = (ev) => this._handle(ev);
    this._pressed = new Set();
  }

  attach() {
    window.addEventListener('keydown', this._handler);
    return () => this.detach();
  }
  detach() { window.removeEventListener('keydown', this._handler); }

  _handle(ev) {
    const k = ev.key;
    const repeat = ev.repeat;

    // Game-over: sólo Enter para reiniciar (lo maneja main vía callback)
    if (this.engine.status === 'over') {
      if (k === 'Enter') {
        ev.preventDefault();
        this.onRestart && this.onRestart();
      }
      return;
    }

    switch (k) {
      case 'ArrowLeft':
        ev.preventDefault();
        this.engine.moveLeft();
        break;
      case 'ArrowRight':
        ev.preventDefault();
        this.engine.moveRight();
        break;
      case 'ArrowDown':
        ev.preventDefault();
        this.engine.softDrop();
        break;
      case 'ArrowUp':
      case 'x': case 'X':
        if (!repeat) this.engine.rotate(1);
        ev.preventDefault();
        break;
      case 'z': case 'Z':
      case 'Control':
        if (!repeat) this.engine.rotate(-1);
        ev.preventDefault();
        break;
      case ' ':
        if (!repeat) this.engine.hardDrop();
        ev.preventDefault();
        break;
      case 'Shift':
      case 'c': case 'C':
        if (!repeat) this.engine.hold();
        ev.preventDefault();
        break;
      case 'p': case 'P':
      case 'Escape':
        if (!repeat) {
          this.onTogglePause ? this.onTogglePause() : this.engine.togglePause();
        }
        ev.preventDefault();
        break;
      case 'Enter':
        if (!repeat && this.engine.status === 'idle') {
          ev.preventDefault();
          this.engine.start();
        }
        break;
    }
  }
}
