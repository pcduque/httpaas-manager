/**
 * Capa: INFRAESTRUCTURA
 * StorageAdapter — wrapper sobre localStorage con fallback en memoria.
 *
 * Si localStorage está deshabilitado (privacidad, modo incógnito estricto,
 * cuotas), caemos a un Map en memoria — la app no truena, simplemente no
 * persiste entre recargas.
 */
const NS = 'tetra.';

let _memory = new Map();

function _hasLocalStorage() {
  try {
    const k = '__tetra_test__';
    localStorage.setItem(k, '1');
    localStorage.removeItem(k);
    return true;
  } catch { return false; }
}

const useLS = _hasLocalStorage();

export const StorageAdapter = {
  get(key) {
    const k = NS + key;
    try {
      if (useLS) {
        const raw = localStorage.getItem(k);
        return raw === null ? null : JSON.parse(raw);
      }
      return _memory.has(k) ? JSON.parse(_memory.get(k)) : null;
    } catch {
      return null;
    }
  },
  set(key, value) {
    const k = NS + key;
    const raw = JSON.stringify(value);
    try {
      if (useLS) localStorage.setItem(k, raw);
      else _memory.set(k, raw);
    } catch (e) {
      console.warn('StorageAdapter: no se pudo persistir', key, e);
    }
  },
  remove(key) {
    const k = NS + key;
    if (useLS) localStorage.removeItem(k);
    else _memory.delete(k);
  },
};
