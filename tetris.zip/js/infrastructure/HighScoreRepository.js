/**
 * Capa: INFRAESTRUCTURA
 * HighScoreRepository — Persiste el TOP 5 de puntajes en localStorage.
 *
 * Estructura guardada bajo la clave 'highscores':
 *   [
 *     { name: 'AAA', score: 12300, lines: 24, level: 4, date: '2025-...' },
 *     ...
 *   ]
 * Ordenado de mayor a menor por score, máximo MAX entradas.
 */
import { StorageAdapter } from './StorageAdapter.js';

const KEY = 'highscores';
const MAX = 5;

export class HighScoreRepository {
  loadAll() {
    const data = StorageAdapter.get(KEY);
    if (!Array.isArray(data)) return [];
    return data;
  }

  /** Devuelve el mejor puntaje (o null si no hay). */
  best() {
    const all = this.loadAll();
    return all.length ? all[0] : null;
  }

  /** ¿Este score entraría al top? */
  qualifies(score) {
    if (score <= 0) return false;
    const all = this.loadAll();
    if (all.length < MAX) return true;
    return score > all[all.length - 1].score;
  }

  /** Inserta una entrada y devuelve la nueva lista ordenada y truncada.
   *  Devuelve también el `position` (1-based) si entró, o null si no entró. */
  add({ name, score, lines, level }) {
    const entry = {
      name: (name || 'INVITADO').toUpperCase().slice(0, 6),
      score, lines, level,
      date: new Date().toISOString(),
    };
    const all = this.loadAll();
    all.push(entry);
    all.sort((a, b) => b.score - a.score);
    const truncated = all.slice(0, MAX);
    StorageAdapter.set(KEY, truncated);
    const position = truncated.findIndex(e => e === entry);
    return { list: truncated, position: position >= 0 ? position + 1 : null };
  }

  clear() { StorageAdapter.remove(KEY); }
}
