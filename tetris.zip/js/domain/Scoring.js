/**
 * Capa: DOMINIO
 * Scoring — Reglas puras de puntaje, nivel y velocidad.
 *
 * Tabla clásica (NES/Tetris Guidelines simplificadas):
 *   1 línea  : 100 × nivel       (single)
 *   2 líneas : 300 × nivel       (double)
 *   3 líneas : 500 × nivel       (triple)
 *   4 líneas : 800 × nivel       (TETRIS — bonus)
 *
 * Soft drop: 1 punto por celda descendida.
 * Hard drop: 2 puntos por celda descendida.
 *
 * Nivel: empieza en 1; sube cada 10 líneas eliminadas (acumuladas).
 * Gravedad (ms entre caídas) decrece con el nivel pero nunca por debajo de
 * un mínimo razonable.
 */

const LINE_POINTS = [0, 100, 300, 500, 800];
const LINES_PER_LEVEL = 10;
const MIN_GRAVITY_MS = 80;
const BASE_GRAVITY_MS = 900;
const GRAVITY_STEP_MS = 75;

export const SOFT_DROP_POINTS = 1;
export const HARD_DROP_POINTS = 2;

/** Puntos por filas eliminadas a un nivel dado. */
export function scoreForLines(linesCleared, level) {
  if (linesCleared < 0 || linesCleared > 4) return 0;
  return LINE_POINTS[linesCleared] * level;
}

/** Nivel calculado a partir del total acumulado de líneas. */
export function levelFromLines(totalLines) {
  return Math.floor(totalLines / LINES_PER_LEVEL) + 1;
}

/** Líneas que faltan para subir al siguiente nivel. */
export function linesToNextLevel(totalLines) {
  const next = (Math.floor(totalLines / LINES_PER_LEVEL) + 1) * LINES_PER_LEVEL;
  return next - totalLines;
}

/** Intervalo de gravedad (ms) para un nivel. */
export function gravityMsForLevel(level) {
  const ms = BASE_GRAVITY_MS - (level - 1) * GRAVITY_STEP_MS;
  return Math.max(MIN_GRAVITY_MS, ms);
}

/** Mensaje breve por línea eliminada (para mostrar como toast). */
export function lineClearLabel(n) {
  switch (n) {
    case 1: return 'Single';
    case 2: return 'Double';
    case 3: return 'Triple';
    case 4: return 'TETRIS';
    default: return null;
  }
}
