/**
 * Capa: DOMINIO
 * PieceFactory — Generador de piezas usando 7-bag randomizer.
 *
 * El estándar moderno: en cada "bolsa" se barajan los 7 tetrominoes y se
 * devuelven uno por uno; cuando se vacía, se rellena. Eso garantiza que
 * nunca pasen más de 12 piezas sin que aparezca una específica.
 */
import { Tetromino, PIECE_IDS } from './Tetromino.js';

export class PieceFactory {
  constructor(spawnX = 3, spawnY = 0, rng = Math.random) {
    this._spawnX = spawnX;
    this._spawnY = spawnY;
    this._rng = rng;
    this._bag = [];
  }

  _refill() {
    const ids = [...PIECE_IDS];
    // Fisher–Yates shuffle
    for (let i = ids.length - 1; i > 0; i--) {
      const j = Math.floor(this._rng() * (i + 1));
      [ids[i], ids[j]] = [ids[j], ids[i]];
    }
    this._bag.push(...ids);
  }

  /** Devuelve el siguiente id de pieza (sin instanciar). */
  peekNextId() {
    if (this._bag.length === 0) this._refill();
    return this._bag[0];
  }

  /** Devuelve los próximos N ids sin consumirlos (para preview). */
  peekUpcoming(n = 1) {
    while (this._bag.length < n) this._refill();
    return this._bag.slice(0, n);
  }

  /** Saca la siguiente pieza ya instanciada en posición de spawn. */
  next() {
    if (this._bag.length === 0) this._refill();
    const id = this._bag.shift();
    // I-piece centrada con su offset propio (matriz 4x4); el resto con offset 3
    const x = id === 'I' ? this._spawnX : this._spawnX;
    const y = this._spawnY;
    return new Tetromino(id, x, y, 0);
  }
}
