/**
 * Capa: DOMINIO
 * Board — Cuadrícula del tablero con lógica de:
 *   - colisión (canPlace)
 *   - bloqueo (lock)
 *   - detección y limpieza de filas completas
 *
 * El tablero estándar es 10 columnas × 20 filas visibles.
 * Internamente almacenamos también filas "buffer" arriba para spawnear con
 * holgura — pero el grid expuesto es siempre el visible.
 *
 * Cada celda guarda 0 (vacío) o el id de la pieza que la ocupa ('I'..'L').
 */

export const COLS = 10;
export const ROWS = 20;
export const BUFFER_ROWS = 2;       // filas invisibles arriba para spawn
const TOTAL_ROWS = ROWS + BUFFER_ROWS;

export class Board {
  constructor() {
    this.grid = Board.emptyGrid();
  }

  static emptyGrid() {
    return Array.from({ length: TOTAL_ROWS }, () => Array(COLS).fill(0));
  }

  reset() { this.grid = Board.emptyGrid(); }

  /** Coordenada interna (con offset por buffer) → fila/columna del array. */
  _toInternalRow(y) { return y + BUFFER_ROWS; }

  /** ¿La celda absoluta (x,y) está ocupada o fuera de los límites? */
  isOccupied(x, y) {
    if (x < 0 || x >= COLS) return true;
    if (y >= ROWS) return true;
    const ry = this._toInternalRow(y);
    if (ry < 0) return false;             // arriba del buffer: libre
    return this.grid[ry][x] !== 0;
  }

  /** ¿La pieza puede ubicarse en su posición actual? */
  canPlace(piece) {
    let ok = true;
    piece.forEachCell((x, y) => {
      if (!ok) return;
      if (this.isOccupied(x, y)) ok = false;
    });
    return ok;
  }

  /** Bloquea la pieza (la pinta en el grid). Devuelve true si alguna celda
   *  cayó dentro del área visible (si no, el lock fue arriba → game over). */
  lock(piece) {
    let lockedInside = false;
    piece.forEachCell((x, y) => {
      const ry = this._toInternalRow(y);
      if (ry < 0) return;                 // celda lockeada arriba del buffer
      if (ry >= 0 && ry < TOTAL_ROWS && x >= 0 && x < COLS) {
        this.grid[ry][x] = piece.color;
        if (y >= 0) lockedInside = true;
      }
    });
    return lockedInside;
  }

  /** Devuelve los índices (fila ABSOLUTA, no interna) de las filas completas. */
  findFullRows() {
    const rows = [];
    for (let y = 0; y < ROWS; y++) {
      const ry = this._toInternalRow(y);
      if (this.grid[ry].every(cell => cell !== 0)) rows.push(y);
    }
    return rows;
  }

  /** Limpia las filas dadas y compacta arriba con filas vacías. */
  clearRows(rows) {
    if (rows.length === 0) return 0;
    const internalRows = rows.map(y => this._toInternalRow(y));
    // Filtramos el grid quitando esas filas, luego prependemos vacías arriba.
    const remaining = this.grid.filter((_, i) => !internalRows.includes(i));
    while (remaining.length < TOTAL_ROWS) {
      remaining.unshift(Array(COLS).fill(0));
    }
    this.grid = remaining;
    return rows.length;
  }

  /** Snapshot del grid SOLO de las filas visibles (para el renderer). */
  visibleGrid() {
    return this.grid.slice(BUFFER_ROWS);
  }

  /** Devuelve la pieza tras dejarla caer hasta justo antes de colisionar
   *  (útil para el ghost piece). NO modifica el tablero. */
  ghostFor(piece) {
    let ghost = piece;
    while (true) {
      const next = ghost.moved(0, 1);
      if (!this.canPlace(next)) break;
      ghost = next;
    }
    return ghost;
  }

  /** ¿La pieza ya superpuesta en spawn implica game over? */
  isSpawnBlocked(piece) {
    return !this.canPlace(piece);
  }
}
