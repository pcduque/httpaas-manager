/**
 * Capa: DOMINIO
 * Tetromino — Definición de las 7 piezas con sus 4 estados de rotación.
 *
 * Cada pieza es un objeto inmutable con:
 *   - id:        identificador 'I' | 'O' | 'T' | 'S' | 'Z' | 'J' | 'L'
 *   - color:     clave de paleta (mapea a --p-X en CSS / Renderer)
 *   - rotations: arreglo de 4 matrices (cada una NxN de 0/1)
 *
 * Las matrices siguen la convención SRS (Super Rotation System).
 */

const SHAPES = {
  I: {
    id: 'I', color: 'I',
    rotations: [
      [[0,0,0,0],
       [1,1,1,1],
       [0,0,0,0],
       [0,0,0,0]],
      [[0,0,1,0],
       [0,0,1,0],
       [0,0,1,0],
       [0,0,1,0]],
      [[0,0,0,0],
       [0,0,0,0],
       [1,1,1,1],
       [0,0,0,0]],
      [[0,1,0,0],
       [0,1,0,0],
       [0,1,0,0],
       [0,1,0,0]],
    ],
  },
  O: {
    id: 'O', color: 'O',
    rotations: [
      [[1,1],
       [1,1]],
      [[1,1],
       [1,1]],
      [[1,1],
       [1,1]],
      [[1,1],
       [1,1]],
    ],
  },
  T: {
    id: 'T', color: 'T',
    rotations: [
      [[0,1,0],
       [1,1,1],
       [0,0,0]],
      [[0,1,0],
       [0,1,1],
       [0,1,0]],
      [[0,0,0],
       [1,1,1],
       [0,1,0]],
      [[0,1,0],
       [1,1,0],
       [0,1,0]],
    ],
  },
  S: {
    id: 'S', color: 'S',
    rotations: [
      [[0,1,1],
       [1,1,0],
       [0,0,0]],
      [[0,1,0],
       [0,1,1],
       [0,0,1]],
      [[0,0,0],
       [0,1,1],
       [1,1,0]],
      [[1,0,0],
       [1,1,0],
       [0,1,0]],
    ],
  },
  Z: {
    id: 'Z', color: 'Z',
    rotations: [
      [[1,1,0],
       [0,1,1],
       [0,0,0]],
      [[0,0,1],
       [0,1,1],
       [0,1,0]],
      [[0,0,0],
       [1,1,0],
       [0,1,1]],
      [[0,1,0],
       [1,1,0],
       [1,0,0]],
    ],
  },
  J: {
    id: 'J', color: 'J',
    rotations: [
      [[1,0,0],
       [1,1,1],
       [0,0,0]],
      [[0,1,1],
       [0,1,0],
       [0,1,0]],
      [[0,0,0],
       [1,1,1],
       [0,0,1]],
      [[0,1,0],
       [0,1,0],
       [1,1,0]],
    ],
  },
  L: {
    id: 'L', color: 'L',
    rotations: [
      [[0,0,1],
       [1,1,1],
       [0,0,0]],
      [[0,1,0],
       [0,1,0],
       [0,1,1]],
      [[0,0,0],
       [1,1,1],
       [1,0,0]],
      [[1,1,0],
       [0,1,0],
       [0,1,0]],
    ],
  },
};

export const PIECE_IDS = ['I', 'O', 'T', 'S', 'Z', 'J', 'L'];

/**
 * Pieza activa — instancia mutable mínima (posición, rotación).
 * La forma viene del catálogo SHAPES indexada por su id.
 */
export class Tetromino {
  constructor(id, x, y, rotationIndex = 0) {
    if (!SHAPES[id]) throw new Error(`Tetromino: id desconocido ${id}`);
    this.id = id;
    this.color = SHAPES[id].color;
    this.x = x;
    this.y = y;
    this.rotationIndex = rotationIndex;
  }

  /** Matriz de la pieza en su rotación actual. */
  get matrix() {
    return SHAPES[this.id].rotations[this.rotationIndex];
  }

  /** Tamaño de la matriz cuadrada (N×N). */
  get size() {
    return this.matrix.length;
  }

  /** Devuelve una nueva instancia desplazada. */
  moved(dx, dy) {
    return new Tetromino(this.id, this.x + dx, this.y + dy, this.rotationIndex);
  }

  /** Devuelve una nueva instancia rotada (+1 = horario, -1 = antihorario). */
  rotated(dir = 1) {
    const total = SHAPES[this.id].rotations.length;
    const next = ((this.rotationIndex + dir) % total + total) % total;
    return new Tetromino(this.id, this.x, this.y, next);
  }

  /** Itera sobre las celdas ocupadas (en coords absolutas del tablero). */
  forEachCell(fn) {
    const m = this.matrix;
    for (let r = 0; r < m.length; r++) {
      for (let c = 0; c < m[r].length; c++) {
        if (m[r][c]) fn(this.x + c, this.y + r);
      }
    }
  }

  /** Iterador con coords locales (útil para previews). */
  forEachLocalCell(fn) {
    const m = this.matrix;
    for (let r = 0; r < m.length; r++) {
      for (let c = 0; c < m[r].length; c++) {
        if (m[r][c]) fn(c, r);
      }
    }
  }
}

/** Acceso de solo lectura a las definiciones (para previews / tests). */
export function getShape(id) {
  if (!SHAPES[id]) throw new Error(`getShape: id desconocido ${id}`);
  return SHAPES[id];
}
