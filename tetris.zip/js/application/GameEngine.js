/**
 * Capa: APLICACIÓN
 * GameEngine — Orquesta el ciclo de juego.
 *
 * Mantiene el estado mutable (board, pieza activa, score, nivel, etc.) y
 * expone:
 *   - Comandos:    start, pause, resume, restart, moveLeft, moveRight,
 *                  rotate, softDrop, hardDrop, hold
 *   - Suscripción: on(event, cb) → unsubscribe
 *
 * Emite eventos con la información mínima que el renderer/HUD necesitan,
 * sin filtrar tipos de la capa de presentación. La capa de presentación se
 * suscribe y dibuja según convenga.
 *
 * Eventos emitidos:
 *   'state'         — snapshot completo (cada cambio relevante)
 *   'lock'          — { rowsCleared, label }
 *   'levelup'       — { level }
 *   'gameover'      — { score, lines, level }
 *   'pause' / 'resume' / 'start' / 'restart'
 */
import { Board, COLS, ROWS } from '../domain/Board.js';
import { PieceFactory } from '../domain/PieceFactory.js';
import {
  scoreForLines, levelFromLines, gravityMsForLevel,
  lineClearLabel, SOFT_DROP_POINTS, HARD_DROP_POINTS,
} from '../domain/Scoring.js';

const STATUS = Object.freeze({
  IDLE:    'idle',
  PLAYING: 'playing',
  PAUSED:  'paused',
  OVER:    'over',
});

export const GameStatus = STATUS;

export class GameEngine {
  constructor() {
    this.board = new Board();
    this.factory = new PieceFactory();
    this.piece = null;
    this.holdPiece = null;       // tetromino "ghost" (sólo id+rotación visual)
    this.holdUsedThisTurn = false;
    this.score = 0;
    this.lines = 0;
    this.level = 1;
    this.status = STATUS.IDLE;

    // Loop de gravedad
    this._lastTick = 0;
    this._accum = 0;
    this._rafId = null;

    // Pub/Sub
    this._listeners = new Map();
  }

  /* ---------------------------------------------------------------- *
   *  Pub/Sub                                                          *
   * ---------------------------------------------------------------- */
  on(event, cb) {
    if (!this._listeners.has(event)) this._listeners.set(event, new Set());
    this._listeners.get(event).add(cb);
    return () => this._listeners.get(event)?.delete(cb);
  }
  _emit(event, payload) {
    const set = this._listeners.get(event);
    if (set) set.forEach(cb => { try { cb(payload); } catch (e) { console.error(e); } });
  }
  _emitState() { this._emit('state', this.snapshot()); }

  /* ---------------------------------------------------------------- *
   *  Snapshot                                                         *
   * ---------------------------------------------------------------- */
  snapshot() {
    const ghost = this.piece && this.status === STATUS.PLAYING
      ? this.board.ghostFor(this.piece) : null;
    return {
      grid: this.board.visibleGrid(),
      piece: this.piece,
      ghost,
      hold: this.holdPiece,
      next: this.factory.peekUpcoming(1)[0] || null,
      score: this.score,
      lines: this.lines,
      level: this.level,
      status: this.status,
    };
  }

  /* ---------------------------------------------------------------- *
   *  Comandos                                                         *
   * ---------------------------------------------------------------- */
  start() {
    if (this.status === STATUS.PLAYING) return;
    this.board.reset();
    this.factory = new PieceFactory();
    this.piece = null;
    this.holdPiece = null;
    this.holdUsedThisTurn = false;
    this.score = 0;
    this.lines = 0;
    this.level = 1;
    this.status = STATUS.PLAYING;
    this._spawnNext();
    this._lastTick = performance.now();
    this._accum = 0;
    this._loop();
    this._emit('start');
    this._emitState();
  }

  restart() {
    this._stopLoop();
    this.start();
    this._emit('restart');
  }

  pause() {
    if (this.status !== STATUS.PLAYING) return;
    this.status = STATUS.PAUSED;
    this._stopLoop();
    this._emit('pause');
    this._emitState();
  }

  resume() {
    if (this.status !== STATUS.PAUSED) return;
    this.status = STATUS.PLAYING;
    this._lastTick = performance.now();
    this._loop();
    this._emit('resume');
    this._emitState();
  }

  togglePause() {
    if (this.status === STATUS.PLAYING) this.pause();
    else if (this.status === STATUS.PAUSED) this.resume();
  }

  moveLeft()  { this._tryMove(-1, 0); }
  moveRight() { this._tryMove( 1, 0); }

  softDrop() {
    if (this.status !== STATUS.PLAYING || !this.piece) return;
    const moved = this.piece.moved(0, 1);
    if (this.board.canPlace(moved)) {
      this.piece = moved;
      this.score += SOFT_DROP_POINTS;
      this._emitState();
    } else {
      // Si no puede bajar, lock inmediato (comportamiento estándar de soft drop)
      this._lockAndAdvance();
    }
  }

  hardDrop() {
    if (this.status !== STATUS.PLAYING || !this.piece) return;
    let dropped = 0;
    while (true) {
      const next = this.piece.moved(0, 1);
      if (!this.board.canPlace(next)) break;
      this.piece = next;
      dropped++;
    }
    this.score += dropped * HARD_DROP_POINTS;
    this._lockAndAdvance();
  }

  rotate(dir = 1) {
    if (this.status !== STATUS.PLAYING || !this.piece) return;
    const rotated = this.piece.rotated(dir);
    // Wall kicks simples (no SRS completo): probamos ±1, ±2 columnas
    const kicks = [0, -1, 1, -2, 2];
    for (const dx of kicks) {
      const candidate = rotated.moved(dx, 0);
      if (this.board.canPlace(candidate)) {
        this.piece = candidate;
        this._emitState();
        return;
      }
    }
    // No encontró posición válida → ignora rotación
  }

  hold() {
    if (this.status !== STATUS.PLAYING || !this.piece) return;
    if (this.holdUsedThisTurn) return;
    const currentId = this.piece.id;
    if (this.holdPiece) {
      // Intercambia: la guardada vuelve a la cancha en posición de spawn
      const swappedId = this.holdPiece.id;
      this.holdPiece = { id: currentId };
      this._spawnSpecific(swappedId);
    } else {
      this.holdPiece = { id: currentId };
      this._spawnNext();
    }
    this.holdUsedThisTurn = true;
    this._emitState();
  }

  /* ---------------------------------------------------------------- *
   *  Internos                                                         *
   * ---------------------------------------------------------------- */
  _tryMove(dx, dy) {
    if (this.status !== STATUS.PLAYING || !this.piece) return;
    const moved = this.piece.moved(dx, dy);
    if (this.board.canPlace(moved)) {
      this.piece = moved;
      this._emitState();
    }
  }

  _spawnNext() {
    const piece = this.factory.next();
    // Centramos en X. La Y de spawn es 0: las piezas con fila superior llena
    // (como la O) entran completas; las que tienen fila 0 vacía (I, T, S, Z, J, L)
    // aparecen visualmente desde la fila 1 — comportamiento estándar.
    piece.x = Math.floor((COLS - piece.size) / 2);
    piece.y = 0;
    this.piece = piece;
    this.holdUsedThisTurn = false;
    if (this.board.isSpawnBlocked(piece)) {
      this._gameOver();
    }
  }

  _spawnSpecific(id) {
    // Forzamos una pieza concreta (usado por hold)
    const factory = this.factory;
    // Inyectamos al frente de la bolsa
    factory._bag.unshift(id);
    this._spawnNext();
  }

  _lockAndAdvance() {
    if (!this.piece) return;
    const lockedInside = this.board.lock(this.piece);
    const fullRows = this.board.findFullRows();
    const cleared = this.board.clearRows(fullRows);

    if (cleared > 0) {
      const points = scoreForLines(cleared, this.level);
      this.score += points;
      this.lines += cleared;
      const newLevel = levelFromLines(this.lines);
      const leveledUp = newLevel > this.level;
      this.level = newLevel;
      this._emit('lock', { rowsCleared: cleared, label: lineClearLabel(cleared), points });
      if (leveledUp) this._emit('levelup', { level: this.level });
    } else {
      this._emit('lock', { rowsCleared: 0, label: null, points: 0 });
    }

    if (!lockedInside) {
      this._gameOver();
      return;
    }

    this._spawnNext();
    this._emitState();
  }

  _gameOver() {
    this.status = STATUS.OVER;
    this._stopLoop();
    this._emit('gameover', {
      score: this.score, lines: this.lines, level: this.level,
    });
    this._emitState();
  }

  /* ---------------------------------------------------------------- *
   *  Loop de gravedad                                                 *
   * ---------------------------------------------------------------- */
  _loop = () => {
    if (this.status !== STATUS.PLAYING) return;
    const now = performance.now();
    const dt = now - this._lastTick;
    this._lastTick = now;
    this._accum += dt;
    const interval = gravityMsForLevel(this.level);
    while (this._accum >= interval) {
      this._gravityTick();
      this._accum -= interval;
      if (this.status !== STATUS.PLAYING) break;
    }
    this._rafId = requestAnimationFrame(this._loop);
  };

  _stopLoop() {
    if (this._rafId !== null) {
      cancelAnimationFrame(this._rafId);
      this._rafId = null;
    }
  }

  _gravityTick() {
    if (!this.piece) return;
    const moved = this.piece.moved(0, 1);
    if (this.board.canPlace(moved)) {
      this.piece = moved;
      this._emitState();
    } else {
      this._lockAndAdvance();
    }
  }
}
