/**
 * Capa: PRESENTACIÓN
 * Renderer — Pinta el tablero principal sobre un <canvas>.
 *
 * Soporta HiDPI (multiplica por devicePixelRatio internamente y usa
 * un transform para que el resto del código piense en "px CSS").
 *
 * Pintamos en orden: fondo → grid lines → ghost → celdas bloqueadas →
 * pieza activa.
 */
import { COLS, ROWS } from '../domain/Board.js';
import { PIECE_COLORS, PIECE_COLORS_SOFT } from './Palette.js';

const CELL = 30;          // px CSS por celda
const PADDING = 2;        // padding interno del bloque (paper-line)

export class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this._resizeForDPR();
  }

  /** Ajusta el canvas al CSS de COLS×ROWS celdas y a HiDPI. */
  _resizeForDPR() {
    const dpr = window.devicePixelRatio || 1;
    const cssW = COLS * CELL;
    const cssH = ROWS * CELL;
    this.canvas.style.width = cssW + 'px';
    this.canvas.style.height = cssH + 'px';
    this.canvas.width = cssW * dpr;
    this.canvas.height = cssH * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  /** Limpia y dibuja todo el snapshot. */
  draw(snapshot) {
    const ctx = this.ctx;
    const cssW = COLS * CELL;
    const cssH = ROWS * CELL;

    // Fondo
    ctx.fillStyle = this._cssVar('--grid-bg', '#F5EFE2');
    ctx.fillRect(0, 0, cssW, cssH);

    // Grid lines sutiles
    this._drawGridLines();

    // Ghost (sólo si jugando)
    if (snapshot.ghost && snapshot.status === 'playing') {
      snapshot.ghost.forEachCell((x, y) => {
        if (y < 0) return;
        this._drawCell(x, y, PIECE_COLORS_SOFT[snapshot.ghost.color], true);
      });
    }

    // Bloqueadas (visible grid, ya recortado)
    for (let y = 0; y < snapshot.grid.length; y++) {
      for (let x = 0; x < snapshot.grid[y].length; x++) {
        const c = snapshot.grid[y][x];
        if (c) this._drawCell(x, y, PIECE_COLORS[c] || '#999');
      }
    }

    // Pieza activa
    if (snapshot.piece) {
      snapshot.piece.forEachCell((x, y) => {
        if (y < 0) return;       // arriba del visible: no pintamos
        this._drawCell(x, y, PIECE_COLORS[snapshot.piece.color] || '#999');
      });
    }

    // Overlay de pausa
    if (snapshot.status === 'paused') {
      ctx.fillStyle = 'rgba(31, 27, 22, 0.38)';
      ctx.fillRect(0, 0, cssW, cssH);
      ctx.fillStyle = '#FAF7F0';
      ctx.font = '700 22px Georgia, serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('Pausa', cssW / 2, cssH / 2);
    }

    // Overlay de game over (más sutil — el modal hace el resto)
    if (snapshot.status === 'over') {
      ctx.fillStyle = 'rgba(31, 27, 22, 0.45)';
      ctx.fillRect(0, 0, cssW, cssH);
    }

    // Overlay de idle (start screen)
    if (snapshot.status === 'idle') {
      ctx.fillStyle = 'rgba(250, 247, 240, 0.78)';
      ctx.fillRect(0, 0, cssW, cssH);
      ctx.fillStyle = '#1F1B16';
      ctx.font = '700 24px Georgia, serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('Listo para jugar', cssW / 2, cssH / 2 - 10);
      ctx.fillStyle = '#7A6E61';
      ctx.font = '600 11px "SF Mono", Menlo, monospace';
      ctx.fillText('PRESIONÁ START O ENTER', cssW / 2, cssH / 2 + 18);
    }
  }

  _drawGridLines() {
    const ctx = this.ctx;
    ctx.strokeStyle = this._cssVar('--grid-line', '#E0D6C2');
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = 1; x < COLS; x++) {
      ctx.moveTo(x * CELL + 0.5, 0);
      ctx.lineTo(x * CELL + 0.5, ROWS * CELL);
    }
    for (let y = 1; y < ROWS; y++) {
      ctx.moveTo(0, y * CELL + 0.5);
      ctx.lineTo(COLS * CELL, y * CELL + 0.5);
    }
    ctx.stroke();
  }

  _drawCell(x, y, color, isGhost = false) {
    const ctx = this.ctx;
    const px = x * CELL;
    const py = y * CELL;

    if (isGhost) {
      // Ghost: outline + fill suave
      ctx.fillStyle = color;
      ctx.fillRect(px + 2, py + 2, CELL - 4, CELL - 4);
      ctx.strokeStyle = 'rgba(31, 27, 22, 0.22)';
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.strokeRect(px + 2.5, py + 2.5, CELL - 5, CELL - 5);
      ctx.setLineDash([]);
      return;
    }

    // Cuerpo del bloque (con padding para mostrar la cuadrícula)
    ctx.fillStyle = color;
    ctx.fillRect(px + PADDING, py + PADDING, CELL - PADDING * 2, CELL - PADDING * 2);

    // Highlight diagonal sutil (top-left)
    ctx.fillStyle = 'rgba(255, 255, 255, 0.18)';
    ctx.beginPath();
    ctx.moveTo(px + PADDING, py + PADDING);
    ctx.lineTo(px + CELL - PADDING, py + PADDING);
    ctx.lineTo(px + PADDING, py + CELL - PADDING);
    ctx.closePath();
    ctx.fill();

    // Borde interno oscuro (bottom-right) — efecto bloque tallado
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.18)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(px + CELL - PADDING - 0.5, py + PADDING + 0.5);
    ctx.lineTo(px + CELL - PADDING - 0.5, py + CELL - PADDING - 0.5);
    ctx.lineTo(px + PADDING + 0.5, py + CELL - PADDING - 0.5);
    ctx.stroke();
  }

  _cssVar(name, fallback) {
    try {
      const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
      return v || fallback;
    } catch { return fallback; }
  }
}
