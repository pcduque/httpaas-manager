/**
 * Capa: PRESENTACIÓN
 * Modal — Gestiona los modales superpuestos (pausa, game over, guardar
 * puntaje). Una sola instancia, controlada por main.js vía show... / close.
 */
import { padScore, formatNumber, escapeHtml } from './format.js';

const ICONS = {
  pause: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="6" x2="9" y2="18"/><line x1="15" y1="6" x2="15" y2="18"/></svg>`,
  over:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><line x1="9" y1="9" x2="15" y2="15"/><line x1="15" y1="9" x2="9" y2="15"/></svg>`,
  trophy:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4z"/><path d="M17 5h3v3a3 3 0 0 1-3 3M7 5H4v3a3 3 0 0 0 3 3"/></svg>`,
};

export class ModalManager {
  constructor(rootEl) {
    this.root = rootEl;
    this._currentResolve = null;
  }

  close() {
    this.root.innerHTML = '';
    this.root.style.display = 'none';
    if (this._currentResolve) {
      const r = this._currentResolve;
      this._currentResolve = null;
      r(null);
    }
  }

  _open(html) {
    this.root.innerHTML = `<div class="modal-backdrop">${html}</div>`;
    this.root.style.display = 'block';
  }

  showPause({ onResume, onRestart }) {
    this._open(`
      <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
        <div class="icon-circle is-paused">${ICONS.pause}</div>
        <div class="eyebrow">El juego está en pausa</div>
        <h2 id="modalTitle">Tomate un respiro</h2>
        <p class="lead">Volvé cuando quieras. Tu progreso se mantiene.</p>
        <div class="modal-actions">
          <button class="btn btn-primary" data-action="resume">Continuar</button>
          <button class="btn btn-ghost" data-action="restart">Reiniciar</button>
        </div>
      </div>
    `);
    this.root.querySelector('[data-action="resume"]').addEventListener('click', () => {
      this.close(); onResume && onResume();
    });
    this.root.querySelector('[data-action="restart"]').addEventListener('click', () => {
      this.close(); onRestart && onRestart();
    });
  }

  showGameOver({ score, lines, level, isHighScore, onRestart, onSaveScore }) {
    const headline = isHighScore ? '¡Nuevo récord!' : 'Fin de la partida';
    const eyebrow = isHighScore
      ? 'Entraste al top 5'
      : 'Buen intento — probá de nuevo';
    const formHtml = isHighScore ? `
      <form class="score-form" data-form="save">
        <label for="player-name">Tus iniciales</label>
        <input type="text" id="player-name" name="name" maxlength="6"
               placeholder="Ej. ANA"
               autocomplete="off" autocapitalize="characters" />
        <span class="hint">Hasta 6 caracteres. Lo que escribas queda guardado.</span>
      </form>` : '';

    this._open(`
      <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
        <div class="icon-circle ${isHighScore ? 'is-success' : 'is-over'}">
          ${isHighScore ? ICONS.trophy : ICONS.over}
        </div>
        <div class="eyebrow">${escapeHtml(eyebrow)}</div>
        <h2 id="modalTitle">${escapeHtml(headline)}</h2>

        <div class="modal-stats">
          <div class="stat is-highlight">
            <div class="label">Puntaje</div>
            <div class="value">${padScore(score)}</div>
          </div>
          <div class="stat">
            <div class="label">Líneas</div>
            <div class="value">${formatNumber(lines)}</div>
          </div>
          <div class="stat">
            <div class="label">Nivel</div>
            <div class="value">${formatNumber(level)}</div>
          </div>
        </div>

        ${formHtml}

        <div class="modal-actions">
          ${isHighScore
            ? '<button class="btn btn-primary" data-action="save">Guardar y reiniciar</button><button class="btn btn-ghost" data-action="skip">Reiniciar sin guardar</button>'
            : '<button class="btn btn-primary" data-action="restart">Jugar de nuevo</button>'}
        </div>
      </div>
    `);

    if (isHighScore) {
      const form = this.root.querySelector('[data-form="save"]');
      const input = this.root.querySelector('#player-name');
      input.focus();
      input.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter') {
          ev.preventDefault();
          this.root.querySelector('[data-action="save"]').click();
        }
      });
      this.root.querySelector('[data-action="save"]').addEventListener('click', () => {
        const name = (input.value || 'INVITADO').trim();
        this.close();
        onSaveScore && onSaveScore(name);
      });
      this.root.querySelector('[data-action="skip"]').addEventListener('click', () => {
        this.close();
        onRestart && onRestart();
      });
    } else {
      this.root.querySelector('[data-action="restart"]').addEventListener('click', () => {
        this.close();
        onRestart && onRestart();
      });
    }
  }
}
