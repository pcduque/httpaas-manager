/**
 * Capa: PRESENTACIÓN
 * Toast — notificaciones efímeras (3 segundos) en la esquina inferior.
 */
export const Toast = {
  show(message, opts = {}) {
    const stack = document.getElementById('toast-stack');
    if (!stack) return;
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = message;
    if (opts.tone === 'accent') el.style.background = 'var(--accent)';
    if (opts.tone === 'leaf')   el.style.background = 'var(--leaf)';
    if (opts.tone === 'gold')   { el.style.background = 'var(--gold)'; el.style.color = 'var(--paper)'; }
    stack.appendChild(el);
    setTimeout(() => el.remove(), opts.duration || 2800);
  },
};
