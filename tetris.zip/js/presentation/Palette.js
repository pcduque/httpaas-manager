/**
 * Capa: PRESENTACIÓN — paleta
 * Palette — mapeo de id de pieza a color canvas.
 *
 * Se sincroniza con los tokens CSS (--p-X). Si querés cambiar la paleta,
 * tocá tanto este objeto como las variables en css/tokens.css.
 */
export const PIECE_COLORS = Object.freeze({
  I: '#3D6B6E',
  O: '#B8893A',
  T: '#7A4262',
  S: '#3D5C49',
  Z: '#C8553D',
  J: '#3B4A6B',
  L: '#B86C2A',
});

/** Versión "soft" para el ghost piece y previsualizaciones. */
export const PIECE_COLORS_SOFT = Object.freeze({
  I: 'rgba(61, 107, 110, 0.22)',
  O: 'rgba(184, 137, 58, 0.22)',
  T: 'rgba(122, 66, 98, 0.22)',
  S: 'rgba(61, 92, 73, 0.22)',
  Z: 'rgba(200, 85, 61, 0.22)',
  J: 'rgba(59, 74, 107, 0.22)',
  L: 'rgba(184, 108, 42, 0.22)',
});
