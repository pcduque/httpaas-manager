/**
 * Capa: PRESENTACIÓN — utilidades
 * format.js: helpers de formato y escape HTML.
 */

/** Formatea un número entero con separadores. */
export function formatNumber(n) {
  try { return new Intl.NumberFormat('es-CO').format(n); }
  catch { return String(n); }
}

/** Pad de score a N dígitos para look retro. */
export function padScore(n, width = 6) {
  const s = String(Math.max(0, n));
  return s.length >= width ? s : '0'.repeat(width - s.length) + s;
}

/** Formatea una fecha ISO en estilo corto es-CO. */
export function formatDate(iso) {
  try {
    return new Intl.DateTimeFormat('es-CO', {
      day: '2-digit', month: 'short', year: 'numeric',
    }).format(new Date(iso));
  } catch { return iso; }
}

/** Escapa para HTML. */
export function escapeHtml(s) {
  if (s === null || s === undefined) return '';
  return String(s)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}
