/**
 * Capa: PRESENTACIÓN
 * PreviewRenderer — Pinta una pieza individual centrada en un canvas chico
 * (usado para el "Next" y el "Hold").
 */
import { getShape } from '../domain/Tetromino.js';
import { PIECE_COLORS } from './Palette.js';

const CELL = 22;
const GRID_W = 4;     // siempre dibujamos en grilla 4×4 para que todas las piezas caigan parejo
const GRID_H = 4;

export class PreviewRenderer {
  constructor(canvas, { dim = false } = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.dim = dim;
    this._resize();
  }

  _resize() {
    const dpr = window.devicePixelRatio || 1;
    const cssW = GRID_W * CELL;
    const cssH = GRID_H * CELL;
    this.canvas.style.width = cssW + 'px';
    this.canvas.style.height = cssH + 'px';
    this.canvas.width = cssW * dpr;
    this.canvas.height = cssH * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  clear() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, GRID_W * CELL, GRID_H * CELL);
  }

  /** Pinta una pieza por id (rotación 0) o limpia si id es null. */
  draw(pieceId) {
    this.clear();
    if (!pieceId) return;
    const shape = getShape(pieceId);
    const matrix = shape.rotations[0];
    const cellsW = matrix[0].length;
    const cellsH = matrix.length;

    // Centrar en grilla 4×4
    const offsetX = Math.floor((GRID_W - cellsW) / 2);
    const offsetY = Math.floor((GRID_H - cellsH) / 2);

    const color = PIECE_COLORS[shape.color];

    for (let r = 0; r < cellsH; r++) {
      for (let c = 0; c < cellsW; c++) {
        if (matrix[r][c]) {
          this._drawCell(offsetX + c, offsetY + r, color);
        }
      }
    }

    // Si está "atenuado" (hold ya usado este turno) aplicamos overlay
    if (this.dim) {
      this.ctx.fillStyle = 'rgba(250, 247, 240, 0.55)';
      this.ctx.fillRect(0, 0, GRID_W * CELL, GRID_H * CELL);
    }
  }

  /** Marca el canvas como atenuado (hold no disponible). */
  setDimmed(dim) {
    if (this.dim === dim) return;
    this.dim = dim;
    // Re-pintamos con la última pieza guardada si quisiéramos persistirla.
    // Como diseño, dejamos al caller que vuelva a llamar draw() — más simple.
  }

  _drawCell(x, y, color) {
    const ctx = this.ctx;
    const px = x * CELL;
    const py = y * CELL;
    const pad = 1;

    ctx.fillStyle = color;
    ctx.fillRect(px + pad, py + pad, CELL - pad * 2, CELL - pad * 2);

    // Highlight
    ctx.fillStyle = 'rgba(255, 255, 255, 0.18)';
    ctx.beginPath();
    ctx.moveTo(px + pad, py + pad);
    ctx.lineTo(px + CELL - pad, py + pad);
    ctx.lineTo(px + pad, py + CELL - pad);
    ctx.closePath();
    ctx.fill();

    // Sombra
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.16)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(px + CELL - pad - 0.5, py + pad + 0.5);
    ctx.lineTo(px + CELL - pad - 0.5, py + CELL - pad - 0.5);
    ctx.lineTo(px + pad + 0.5, py + CELL - pad - 0.5);
    ctx.stroke();
  }
}
