/**
 * Capa: PRESENTACIÓN — componente
 * Header — Pinta el header superior con la marca TETRA y enlaces sencillos.
 *
 * Sin nav reactiva: en este juego no hay rutas. Sólo identidad de producto.
 */
export function renderHeader(container) {
  container.innerHTML = `
    <div class="header-inner">
      <a class="brand" href="#" aria-label="TETRA — inicio">
        <span class="brand-mark">T</span>
        <span>TETRA</span>
        <span class="brand-tag">pieza didáctica</span>
      </a>
      <nav class="header-nav" aria-label="Navegación">
        <a class="nav-link is-active" href="#">Jugar</a>
        <a class="nav-link" href="#scores">Puntajes</a>
        <a class="nav-link" href="#help">Ayuda</a>
      </nav>
    </div>
  `;
}
