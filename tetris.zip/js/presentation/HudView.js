/**
 * Capa: PRESENTACIÓN
 * HudView — Sincroniza los paneles laterales (score, lines, level, status,
 * highscores) con el snapshot del engine.
 *
 * Los nodos DOM se pasan por referencia desde main.js para mantener el
 * acoplamiento mínimo.
 */
import { formatNumber, padScore, escapeHtml } from './format.js';

export class HudView {
  constructor({
    scoreEl, linesEl, levelEl, statusEl, highscoreEl, scoresListEl,
  }) {
    this.scoreEl = scoreEl;
    this.linesEl = linesEl;
    this.levelEl = levelEl;
    this.statusEl = statusEl;
    this.highscoreEl = highscoreEl;
    this.scoresListEl = scoresListEl;
    this._lastScore = 0;
  }

  update(snapshot) {
    if (this.scoreEl) {
      const newVal = padScore(snapshot.score);
      if (this.scoreEl.textContent !== newVal) {
        this.scoreEl.textContent = newVal;
        if (snapshot.score > this._lastScore) {
          this.scoreEl.classList.remove('is-bump');
          // Forzamos reflow para reiniciar la animación
          void this.scoreEl.offsetWidth;
          this.scoreEl.classList.add('is-bump');
        }
        this._lastScore = snapshot.score;
      }
    }
    if (this.linesEl) this.linesEl.textContent = formatNumber(snapshot.lines);
    if (this.levelEl) this.levelEl.textContent = formatNumber(snapshot.level);
    if (this.statusEl) this._renderStatus(snapshot.status);
  }

  _renderStatus(status) {
    let cls = 'badge is-leaf';
    let text = 'Jugando';
    switch (status) {
      case 'idle':    cls = 'badge'; text = 'En espera'; break;
      case 'playing': cls = 'badge is-leaf'; text = 'Jugando'; break;
      case 'paused':  cls = 'badge is-paused'; text = 'Pausa'; break;
      case 'over':    cls = 'badge is-over'; text = 'Fin del juego'; break;
    }
    this.statusEl.className = cls;
    this.statusEl.textContent = text;
  }

  /** Renderiza el panel de mejor puntaje y la mini-lista del top 5. */
  renderHighScores(scores, currentScore = null) {
    if (!this.highscoreEl) return;
    if (!scores || scores.length === 0) {
      this.highscoreEl.innerHTML = `
        <div class="label">Mejor puntaje</div>
        <div class="value">000000</div>
        <div class="name">— sin registros aún —</div>`;
    } else {
      const top = scores[0];
      this.highscoreEl.innerHTML = `
        <div class="label">Mejor puntaje</div>
        <div class="value">${padScore(top.score)}</div>
        <div class="name">${escapeHtml(top.name)} · nivel ${formatNumber(top.level)}</div>`;
    }

    if (!this.scoresListEl) return;
    if (!scores || scores.length === 0) {
      this.scoresListEl.innerHTML = '';
      return;
    }
    this.scoresListEl.innerHTML = scores.map((s, i) => {
      const isCurrent = currentScore !== null && s.score === currentScore;
      return `
        <div class="scores-list-row${isCurrent ? ' is-current' : ''}">
          <span class="pos">${i + 1}</span>
          <span class="name">${escapeHtml(s.name)}</span>
          <span class="pts">${padScore(s.score)}</span>
        </div>`;
    }).join('');
  }
}
