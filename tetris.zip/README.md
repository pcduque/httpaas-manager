# Tetra — Tetris didáctico

Pieza educativa: un Tetris **100 % cliente**, escrito en HTML + CSS + JavaScript
vanilla, sin frameworks, sin internet, sin APIs externas. Misma arquitectura
limpia en 4 capas que el proyecto Bazar — pensado para correr sobre la misma
clase de VM Apache2.

---

## 🧩 Lo que demuestra

- **Arquitectura limpia en 4 capas**: `domain/`, `application/`, `infrastructure/`, `presentation/`.
- **Inversión de dependencias** explícita: la composición vive en `js/main.js`.
- **Ningún framework**: solo módulos ES6 nativos. Apache los sirve sin tocar nada.
- **Persistencia local** vía `localStorage` (top 5 de puntajes sobrevive al refresh, con fallback a memoria si está deshabilitado).
- **Renderizado en `<canvas>`** con soporte HiDPI (multiplicación por `devicePixelRatio` para que se vea crisp en retina).
- **7-bag randomizer** estándar de Tetris moderno (cada "bolsa" baraja las 7 piezas).
- **SRS-light**: rotaciones con wall-kicks simples (±1, ±2 columnas).
- **Hold piece + ghost piece**: dos features clásicas de Tetris guideline.
- **Sin internet**: fuentes del sistema, paleta heredada de Bazar, cero CDNs.

---

## 📁 Estructura

```
tetris/
├── index.html
├── css/                            # 9 archivos por responsabilidad
│   ├── reset.css
│   ├── tokens.css                  # paleta, tipografía, espaciado
│   ├── base.css
│   ├── layout.css
│   ├── components.css              # botones, badges, paneles
│   ├── board.css                   # marco del tablero + animaciones
│   ├── hud.css                     # paneles laterales
│   ├── modals.css                  # pausa / game over
│   └── responsive.css
└── js/
    ├── main.js                     # composition root
    ├── domain/                     # reglas puras del juego
    │   ├── Tetromino.js                # 7 piezas × 4 rotaciones (SRS)
    │   ├── PieceFactory.js             # 7-bag randomizer
    │   ├── Board.js                    # grilla, colisión, lock, clear
    │   └── Scoring.js                  # puntos, nivel, gravedad
    ├── application/                # casos de uso / orquestación
    │   └── GameEngine.js               # loop, eventos, comandos
    ├── infrastructure/             # I/O y persistencia
    │   ├── StorageAdapter.js           # wrapper localStorage + fallback
    │   ├── HighScoreRepository.js      # top 5 persistente
    │   └── InputAdapter.js             # teclado
    └── presentation/               # UI
        ├── format.js                   # padScore, formatNumber, escapeHtml
        ├── Palette.js                  # colores de las 7 piezas
        ├── Renderer.js                 # canvas del tablero principal
        ├── PreviewRenderer.js          # canvas mini para Next/Hold
        ├── HudView.js                  # paneles laterales
        ├── Modal.js                    # pausa / game over
        ├── Toast.js                    # notificaciones efímeras
        └── components/
            └── Header.js
```

Las dependencias **siempre** apuntan hacia el dominio:
`presentation → application → domain` y `infrastructure → domain`.
El dominio no importa nada de las otras capas.

---

## 🎮 Reglas y controles

### Puntaje

| Líneas eliminadas | Puntos                |
|-------------------|-----------------------|
| 1 (Single)        | 100 × nivel           |
| 2 (Double)        | 300 × nivel           |
| 3 (Triple)        | 500 × nivel           |
| 4 (TETRIS)        | 800 × nivel           |
| Soft drop         | +1 / celda descendida |
| Hard drop         | +2 / celda descendida |

### Nivel

- Empieza en 1.
- Sube cada 10 líneas eliminadas.
- La gravedad acelera (mínimo 80 ms entre caídas, en niveles altos).

### Controles (teclado)

| Acción              | Tecla                         |
|---------------------|-------------------------------|
| Mover               | `←` `→`                       |
| Rotar (horario)     | `↑` o `X`                     |
| Rotar (antihorario) | `Z`                           |
| Caída suave         | `↓`                           |
| Caída dura          | `Espacio`                     |
| Reservar / cambiar  | `C` o `Shift`                 |
| Pausar              | `P` o `Esc`                   |
| Iniciar             | `Enter` (también botón)       |

---

## 🚀 Deploy en la VM (Apache2)

### 1. Subir el zip por SCP

Desde tu máquina:

```bash
scp tetris.zip usuario@IP-DE-LA-VM:/tmp/
```

### 2. Conectarte por SSH

```bash
ssh usuario@IP-DE-LA-VM
```

### 3. Descomprimir en el docroot

**Opción A — accesible en `http://IP/tetris/`** (recomendada, no pisa el sitio default ni a Bazar si ya está montado):

```bash
sudo unzip /tmp/tetris.zip -d /var/www/html/
sudo chown -R www-data:www-data /var/www/html/tetris
sudo chmod -R 755 /var/www/html/tetris
```

**Opción B — accesible en la raíz `http://IP/`**:

```bash
sudo unzip /tmp/tetris.zip -d /tmp/
sudo rm -f /var/www/html/index.html
sudo cp -r /tmp/tetris/* /var/www/html/
sudo chown -R www-data:www-data /var/www/html
```

> 💡 La Opción A es más limpia y permite tener Bazar y Tetra coexistiendo
> en `http://IP/bazar/` y `http://IP/tetris/`.

### 4. Probar

Apache2 en Ubuntu sirve `.js` con MIME `application/javascript` por defecto,
suficiente para módulos ES6. **No requiere configuración adicional.**

Abrí el navegador:

```
http://IP-DE-LA-VM/tetris/
```

(o `http://IP-DE-LA-VM/` si elegiste la opción B).

---

## 🧹 Limpieza

Para borrar el top 5 de puntajes:
- Botón **"Borrar puntajes"** en el panel derecho, o
- En consola del browser:
  ```js
  Object.keys(localStorage).filter(k => k.startsWith('tetra.')).forEach(k => localStorage.removeItem(k));
  location.reload();
  ```

---

## 📝 Notas técnicas

- **Sin internet**: cero recursos externos. Fuentes exclusivamente del SO
  (Georgia / system-ui / SF Mono).
- **Sin `mod_rewrite`**: la app no usa rutas. Apache la sirve estática.
- **Compatibilidad**: navegadores con módulos ES6 (Chrome 61+, Firefox 60+,
  Safari 11+, Edge 79+). El canvas es estándar HTML5.
- **Reset rápido**: para llevarlo a otra máquina, copiá la carpeta `tetris/`
  entera. No hay build step, no hay `npm install`.

---

## 🧪 Recorrido sugerido para la demo

1. Apertura: pantalla "Listo para jugar" con overlay editorial.
2. Click en **Iniciar** → empieza a caer la primera pieza.
3. Mostrá:
   - Movimiento con flechas.
   - Rotación con `↑`. Probá rotar contra una pared (wall-kick).
   - Hard drop con `Espacio` → la pieza cae instantánea, `+2 / celda`.
   - Hold con `C` → la pieza queda guardada, aparece otra.
4. Eliminá líneas → animación de flash en el marco + toast con el nombre del
   combo (Single / Double / Triple / **TETRIS** en terracota).
5. Llegá a 10 líneas → toast `NIVEL 2`, la gravedad acelera.
6. Pausá con `P` → modal con opciones.
7. Game over → modal con tus stats. Si es récord, te pide iniciales para
   guardar; si no, sólo "Jugar de nuevo".
8. El top 5 aparece en el panel derecho y persiste tras recargar.

---

Hecho con cuidado — Tetra, hermana de Bazar.
